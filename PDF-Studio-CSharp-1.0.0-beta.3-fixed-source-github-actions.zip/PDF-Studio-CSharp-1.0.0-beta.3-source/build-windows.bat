@echo off
setlocal
cd /d "%~dp0"
set /p VERSION=<VERSION
for /f "usebackq delims=" %%V in (`powershell -NoProfile -Command "$x=[xml](Get-Content 'PdfStudio\PdfStudio.csproj'); ($x.Project.PropertyGroup | Where-Object { $_.Version } | Select-Object -First 1).Version"`) do set "PROJECT_VERSION=%%V"
if not "%VERSION%"=="%PROJECT_VERSION%" (
  echo Version mismatch: VERSION=%VERSION%, PdfStudio.csproj=%PROJECT_VERSION%
  exit /b 3
)
if exist publish rmdir /s /q publish
dotnet restore PdfStudio\PdfStudio.csproj --runtime win-x64
if errorlevel 1 exit /b 1
dotnet publish PdfStudio\PdfStudio.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish --no-restore
if errorlevel 1 exit /b 1
publish\PDF-Studio-CSharp.exe --self-test-auto
if errorlevel 1 (
  echo Self-test failed.
  exit /b 2
)
ren "publish\PDF-Studio-CSharp.exe" "PDF-Studio-CSharp-%VERSION%-win-x64.exe"
powershell -NoProfile -Command "Compress-Archive -Force -Path 'publish\PDF-Studio-CSharp-%VERSION%-win-x64.exe','README.md','CHANGELOG.md','THIRD_PARTY_NOTICES.md' -DestinationPath 'publish\PDF-Studio-CSharp-%VERSION%-win-x64.zip'"
if errorlevel 1 exit /b 1
powershell -NoProfile -Command "(Get-FileHash 'publish\PDF-Studio-CSharp-%VERSION%-win-x64.exe' -Algorithm SHA256).Hash + '  PDF-Studio-CSharp-%VERSION%-win-x64.exe' | Set-Content 'publish\PDF-Studio-CSharp-%VERSION%-win-x64.exe.sha256'"
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
  "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "/DMyAppVersion=%VERSION%" installer.iss
  if errorlevel 1 exit /b 1
) else (
  echo Inno Setup 6 not found; installer build skipped.
)
echo Ready: publish\PDF-Studio-CSharp-%VERSION%-win-x64.exe
echo Package: publish\PDF-Studio-CSharp-%VERSION%-win-x64.zip
