using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PdfStudio;

public partial class SignatureWindow : Window
{
    public string? SignaturePath { get; private set; }
    public bool IsTemporary { get; private set; }

    public SignatureWindow()
    {
        InitializeComponent();
        ApplyDrawingSettings();
    }

    private void Clear_Click(object sender, RoutedEventArgs e) => SignatureCanvas.Strokes.Clear();

    private void ColorBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SignatureCanvas is null) return;
        ApplyDrawingSettings();
    }

    private void ThicknessSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (SignatureCanvas is null || ThicknessText is null) return;
        ThicknessText.Text = ThicknessSlider.Value.ToString("0.#");
        ApplyDrawingSettings();
    }

    private void SaveTemplateBox_Changed(object sender, RoutedEventArgs e)
    {
        if (TemplateNameBox is null) return;
        TemplateNameBox.IsEnabled = SaveTemplateBox.IsChecked == true;
        if (TemplateNameBox.IsEnabled && string.IsNullOrWhiteSpace(TemplateNameBox.Text))
            TemplateNameBox.Text = $"Подпись {DateTime.Now:yyyy-MM-dd HH-mm}";
    }

    private void ApplyDrawingSettings()
    {
        var colorText = (ColorBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "#000000";
        var color = (Color)ColorConverter.ConvertFromString(colorText);
        var thickness = ThicknessSlider.Value;
        var attributes = new DrawingAttributes
        {
            Color = color,
            Width = thickness,
            Height = thickness,
            FitToCurve = true,
            IgnorePressure = true
        };
        SignatureCanvas.DefaultDrawingAttributes = attributes;
        foreach (var stroke in SignatureCanvas.Strokes)
            stroke.DrawingAttributes = attributes.Clone();
    }

    private void Apply_Click(object sender, RoutedEventArgs e)
    {
        if (SignatureCanvas.Strokes.Count == 0)
        {
            MessageBox.Show("Сначала нарисуйте подпись.", "Подпись");
            return;
        }

        var bounds = SignatureCanvas.Strokes.GetBounds();
        const double margin = 20;
        var width = Math.Max(1, (int)Math.Ceiling(bounds.Width + margin * 2));
        var height = Math.Max(1, (int)Math.Ceiling(bounds.Height + margin * 2));
        var visual = new DrawingVisual();
        using (var context = visual.RenderOpen())
        {
            context.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, width, height));
            context.PushTransform(new TranslateTransform(margin - bounds.Left, margin - bounds.Top));
            SignatureCanvas.Strokes.Draw(context);
            context.Pop();
        }

        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(visual);
        bitmap.Freeze();

        var saveTemplate = SaveTemplateBox.IsChecked == true;
        var directory = saveTemplate
            ? Path.Combine(App.DataDirectory, "signatures")
            : Path.Combine(Path.GetTempPath(), "PDF Studio CSharp");
        Directory.CreateDirectory(directory);
        var fileName = saveTemplate
            ? SanitizeFileName(TemplateNameBox.Text)
            : $"signature-temp-{Guid.NewGuid():N}";
        if (string.IsNullOrWhiteSpace(fileName))
            fileName = $"signature-{DateTime.Now:yyyyMMdd-HHmmss}";
        var path = GetUniquePath(directory, fileName, ".png");
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using (var stream = File.Create(path)) encoder.Save(stream);

        SignaturePath = path;
        IsTemporary = !saveTemplate;
        DialogResult = true;
    }

    private static string SanitizeFileName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars().ToHashSet();
        return new string(value.Trim().Select(character => invalid.Contains(character) ? '_' : character).ToArray());
    }

    private static string GetUniquePath(string directory, string name, string extension)
    {
        var path = Path.Combine(directory, name + extension);
        var index = 2;
        while (File.Exists(path))
            path = Path.Combine(directory, $"{name} ({index++}){extension}");
        return path;
    }
}