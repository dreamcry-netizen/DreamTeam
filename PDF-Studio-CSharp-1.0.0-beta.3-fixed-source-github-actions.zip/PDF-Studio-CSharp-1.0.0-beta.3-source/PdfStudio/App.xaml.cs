using System.IO;
using System.Windows;
using Serilog;

namespace PdfStudio;

public partial class App : Application
{
    public static string DataDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PDF Studio CSharp");
    public static string LogDirectory { get; } = Path.Combine(DataDirectory, "logs");

    protected override void OnStartup(StartupEventArgs e)
    {
        var settings = SettingsStore.Load();
        Directory.CreateDirectory(LogDirectory);
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(Path.Combine(LogDirectory, "pdf-studio-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: settings.LogRetentionDays,
                outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} | {Level:u3} | {Message:lj}{NewLine}{Exception}")
            .CreateLogger();
        DispatcherUnhandledException += (_, args) =>
        {
            Log.Error(args.Exception, "Необработанная ошибка интерфейса");
            MessageBox.Show($"{args.Exception.Message}\n\nПодробности записаны в журнал.", "Ошибка");
            args.Handled = true;
        };
        ThemeManager.Apply(settings.Theme);
        Log.Information("Запуск PDF Studio C# 1.0.0-beta.3");
        if (e.Args.Length >= 2 && e.Args[0] == "--self-test")
        {
            try { SelfTest.Run(e.Args[1]); Shutdown(0); }
            catch (Exception ex) { Log.Fatal(ex, "Self-test failed"); Shutdown(2); }
            return;
        }
        if (e.Args.Length >= 1 && e.Args[0] == "--self-test-auto")
        {
            try { SelfTest.RunAuto(); Shutdown(0); }
            catch (Exception ex) { Log.Fatal(ex, "Automatic self-test failed"); Shutdown(2); }
            return;
        }
        var window = new MainWindow();
        window.Show();
        if (e.Args.Length >= 1 && File.Exists(e.Args[0]) &&
            Path.GetExtension(e.Args[0]).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
            _ = window.OpenDocumentAsync(e.Args[0]);
        base.OnStartup(e);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        Log.Information("Завершение PDF Studio C#");
        Log.CloseAndFlush();
        base.OnExit(e);
    }
}
