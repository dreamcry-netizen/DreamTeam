using PdfSharp.Drawing;
using PdfSharp.Pdf.IO;
using Serilog;
using System.IO;
using PigDocument = UglyToad.PdfPig.PdfDocument;

namespace PdfStudio;

public static class SelfTest
{
    public static SelfTestResult RunAuto()
    {
        var input = Path.Combine(Path.GetTempPath(),
            $"pdf-studio-csharp-self-test-input-{Guid.NewGuid():N}.pdf");
        try
        {
            using (var document = new PdfSharp.Pdf.PdfDocument())
            {
                var page = document.AddPage();
                page.Width = XUnit.FromPoint(595);
                page.Height = XUnit.FromPoint(842);
                using var graphics = XGraphics.FromPdfPage(page);
                graphics.DrawRectangle(XBrushes.White, new XRect(0, 0, 595, 842));
                graphics.DrawRectangle(XBrushes.Black, new XRect(72, 72, 180, 80));
                document.Save(input);
            }
            return Run(input);
        }
        finally
        {
            if (File.Exists(input)) File.Delete(input);
        }
    }

    public static SelfTestResult Run(string path)
    {
        if (!File.Exists(path)) throw new FileNotFoundException(path);
        using var pig = PigDocument.Open(path);
        if (pig.NumberOfPages < 1) throw new InvalidDataException("PDF has no pages.");
        var bitmap = PdfRenderService.Render(path, 0, out var width, out var height);
        if (bitmap.PixelWidth < 1 || width < 1 || height < 1) throw new InvalidDataException("Render failed.");
        var output = Path.Combine(Path.GetTempPath(),
            $"pdf-studio-csharp-self-test-output-{Guid.NewGuid():N}.pdf");
        try
        {
            using (var doc = PdfReader.Open(path, PdfDocumentOpenMode.Modify))
            {
                using var gfx = XGraphics.FromPdfPage(doc.Pages[0], XGraphicsPdfPageOptions.Append);
                gfx.DrawRectangle(XBrushes.White, new XRect(1, 1, 2, 2));
                doc.Save(output);
            }
            if (!File.Exists(output) || new FileInfo(output).Length < 100)
                throw new IOException("Save failed.");
            using var verification = PigDocument.Open(output);
            if (verification.NumberOfPages != pig.NumberOfPages)
                throw new InvalidDataException("Saved page count mismatch.");
            var verificationBitmap = PdfRenderService.Render(output, 0, out var savedWidth, out var savedHeight);
            if (verificationBitmap.PixelWidth < 1 || savedWidth < 1 || savedHeight < 1)
                throw new InvalidDataException("Saved PDF render failed.");
            var result = new SelfTestResult(
                pig.NumberOfPages, width, height, savedWidth, savedHeight);
            Log.Information(
                "Self-test passed; pages={Pages}, render={Width}x{Height}, saved={SavedWidth}x{SavedHeight}",
                result.Pages, result.Width, result.Height, result.SavedWidth, result.SavedHeight);
            return result;
        }
        finally
        {
            if (File.Exists(output)) File.Delete(output);
        }
    }
}

public sealed record SelfTestResult(
    int Pages,
    int Width,
    int Height,
    int SavedWidth,
    int SavedHeight);