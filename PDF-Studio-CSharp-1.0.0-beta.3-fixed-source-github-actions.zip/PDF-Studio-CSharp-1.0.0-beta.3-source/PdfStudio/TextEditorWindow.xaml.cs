using System.Globalization;
using System.Windows;
using System.Windows.Media;

namespace PdfStudio;

public partial class TextEditorWindow : Window
{
    public TextFormatResult? Result { get; private set; }

    public TextEditorWindow(string text, double size = 12, string font = "Arial")
    {
        InitializeComponent();
        FontBox.ItemsSource = Fonts.SystemFontFamilies
            .Select(x => x.Source)
            .Distinct(StringComparer.CurrentCultureIgnoreCase)
            .OrderBy(x => x)
            .ToList();
        FontBox.SelectedItem = font;
        if (FontBox.SelectedIndex < 0)
            FontBox.SelectedItem = FontBox.Items.Cast<string>().FirstOrDefault(x => x.Equals("Arial", StringComparison.OrdinalIgnoreCase))
                                   ?? FontBox.Items.Cast<string>().FirstOrDefault();
        SizePresetBox.ItemsSource = new[] { 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 28, 32, 36, 48, 60, 72, 96 };
        AlignBox.ItemsSource = new[] { "Слева", "По центру", "Справа", "По ширине" };
        AlignBox.SelectedIndex = 0;
        ColorBox.ItemsSource = new List<string> { "#202020", "#000000", "#555555", "#2783DE", "#C0392B", "#2E7D32" };
        ColorBox.SelectedIndex = 0;
        SizeBox.Text = size.ToString("0.##", CultureInfo.InvariantCulture);
        Editor.Text = text;
        Editor.SelectAll();
        Loaded += (_, _) => Editor.Focus();
    }

    public TextEditorWindow(EditOperation operation)
        : this(operation.Text, operation.FontSize, operation.FontFamily)
    {
        BoldButton.IsChecked = operation.Bold;
        ItalicButton.IsChecked = operation.Italic;
        UnderlineButton.IsChecked = operation.Underline;
        SpacingBox.Text = operation.LineSpacing.ToString("0.##", CultureInfo.InvariantCulture);
        AlignBox.SelectedIndex = operation.Alignment switch
        {
            TextAlignment.Center => 1,
            TextAlignment.Right => 2,
            TextAlignment.Justify => 3,
            _ => 0
        };
        var color = $"#{operation.Color.R:X2}{operation.Color.G:X2}{operation.Color.B:X2}";
        var colors = ColorBox.ItemsSource.Cast<string>().ToList();
        if (!colors.Contains(color, StringComparer.OrdinalIgnoreCase)) colors.Insert(0, color);
        ColorBox.ItemsSource = colors;
        ColorBox.SelectedItem = colors.First(x => x.Equals(color, StringComparison.OrdinalIgnoreCase));
    }

    private void SizePresetBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (SizePresetBox.SelectedItem is int value)
            SizeBox.Text = value.ToString(CultureInfo.InvariantCulture);
    }

    private void AlignBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (Editor is null) return;
        Editor.TextAlignment = AlignBox.SelectedIndex switch
        {
            1 => TextAlignment.Center,
            2 => TextAlignment.Right,
            3 => TextAlignment.Justify,
            _ => TextAlignment.Left
        };
    }

    private void Apply_Click(object sender, RoutedEventArgs e)
    {
        if (!double.TryParse(SizeBox.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var size) || size < 5 || size > 100)
        { MessageBox.Show("Размер должен быть от 5 до 100."); return; }
        if (!double.TryParse(SpacingBox.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var spacing) || spacing < .8 || spacing > 3)
        { MessageBox.Show("Интервал должен быть от 0,8 до 3."); return; }
        var color = (Color)ColorConverter.ConvertFromString(ColorBox.SelectedItem?.ToString() ?? "#202020");
        var alignment = AlignBox.SelectedIndex switch
        {
            1 => TextAlignment.Center,
            2 => TextAlignment.Right,
            3 => TextAlignment.Justify,
            _ => TextAlignment.Left
        };
        Result = new TextFormatResult(Editor.Text, FontBox.SelectedItem?.ToString() ?? "Arial", size,
            BoldButton.IsChecked == true, ItalicButton.IsChecked == true, UnderlineButton.IsChecked == true,
            color, alignment, spacing);
        DialogResult = true;
    }
}

public sealed record TextFormatResult(string Text, string FontFamily, double FontSize, bool Bold, bool Italic,
    bool Underline, Color Color, TextAlignment Alignment, double LineSpacing);
