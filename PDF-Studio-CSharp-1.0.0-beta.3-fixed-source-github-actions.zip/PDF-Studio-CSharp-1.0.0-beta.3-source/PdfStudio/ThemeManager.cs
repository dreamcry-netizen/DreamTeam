using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;

namespace PdfStudio;

public static class ThemeManager
{
    public static readonly string[] Names = ["Серая", "Светлая", "Тёмная"];

    public static void Apply(string theme)
    {
        var dark = theme == "Тёмная";
        var light = theme == "Светлая";
        Set("AppBackground", light ? "#F7F7F7" : dark ? "#1E1E1E" : "#D9D9D9");
        Set("PanelBackground", light ? "#FFFFFF" : dark ? "#292929" : "#E1E1E1");
        Set("ControlBackground", light ? "#F1F1F1" : dark ? "#383838" : "#D0D0D0");
        Set("InputBackground", light ? "#FFFFFF" : dark ? "#242424" : "#F2F2F2");
        Set("CanvasBackground", light ? "#E9E9E9" : dark ? "#151515" : "#B8B8B8");
        Set("Foreground", dark ? "#F1F1F1" : "#272727");
        Set("SecondaryForeground", dark ? "#BDBDBD" : "#666666");
        Set("Border", light ? "#D5D5D5" : dark ? "#555555" : "#ADADAD");
        Set("SelectedBackground", dark ? "#565656" : light ? "#DDEBFA" : "#B7B7B7");
        Set("Accent", dark ? "#5E9FE8" : "#2783DE");
        SettingsStore.SaveTheme(theme);
    }

    private static void Set(string key, string value) =>
        Application.Current.Resources[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(value));
}

public static class SettingsStore
{
    private static string FilePath => Path.Combine(App.DataDirectory, "settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return new AppSettings();
            var settings = JsonSerializer.Deserialize<AppSettings>(
                File.ReadAllText(FilePath),
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new AppSettings();
            settings.Theme = ThemeManager.Names.Contains(settings.Theme) ? settings.Theme : "Серая";
            settings.JpegQuality = Math.Clamp(settings.JpegQuality, 50, 100);
            settings.ExportDpi = settings.ExportDpi is 150 or 200 or 300 or 400
                ? settings.ExportDpi
                : 300;
            settings.OcrDpi = settings.OcrDpi is 200 or 300 or 400 ? settings.OcrDpi : 300;
            settings.LogRetentionDays = Math.Clamp(settings.LogRetentionDays, 1, 90);
            return settings;
        }
        catch
        {
            return new AppSettings();
        }
    }

    public static string LoadTheme() => Load().Theme;

    public static void SaveTheme(string theme)
    {
        var settings = Load();
        settings.Theme = ThemeManager.Names.Contains(theme) ? theme : "Серая";
        Save(settings);
    }

    public static void Save(AppSettings settings)
    {
        Directory.CreateDirectory(App.DataDirectory);
        File.WriteAllText(FilePath, JsonSerializer.Serialize(settings,
            new JsonSerializerOptions { WriteIndented = true }));
    }
}

public sealed class AppSettings
{
    public string Theme { get; set; } = "Тёмная";
    public string DefaultSaveDirectory { get; set; } = "";
    public int JpegQuality { get; set; } = 95;
    public int ExportDpi { get; set; } = 300;
    public string OcrLanguage { get; set; } = "rus+eng";
    public string OcrPsm { get; set; } = "3";
    public int OcrDpi { get; set; } = 300;
    public int LogRetentionDays { get; set; } = 7;
    public bool LogFullPaths { get; set; }
}
