using Docnet.Core;
using Docnet.Core.Models;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace PdfStudio;

public static class PdfRenderService
{
    private static readonly object Sync = new();

    public static BitmapSource Render(string path, int pageIndex, out int width, out int height,
                                      int targetWidth = 1400, int targetHeight = 2000)
    {
        lock (Sync)
        {
            using var docReader = DocLib.Instance.GetDocReader(path, new PageDimensions(targetWidth, targetHeight));
            using var pageReader = docReader.GetPageReader(pageIndex);
            var bytes = pageReader.GetImage();
            width = pageReader.GetPageWidth();
            height = pageReader.GetPageHeight();
            // PDFium returns BGRA pixels with transparent page background.
            // Correctly composite every pixel over white; simply ignoring alpha turns
            // transparent black (0,0,0,0) into an opaque black page.
            for (var i = 0; i < bytes.Length; i += 4)
            {
                var alpha = bytes[i + 3];
                if (alpha < 255)
                {
                    var inverse = 255 - alpha;
                    bytes[i] = (byte)((bytes[i] * alpha + 255 * inverse) / 255);
                    bytes[i + 1] = (byte)((bytes[i + 1] * alpha + 255 * inverse) / 255);
                    bytes[i + 2] = (byte)((bytes[i + 2] * alpha + 255 * inverse) / 255);
                    bytes[i + 3] = 255;
                }
            }
            var bitmap = BitmapSource.Create(width, height, 96, 96, PixelFormats.Bgra32, null, bytes, width * 4);
            bitmap.Freeze();
            return bitmap;
        }
    }
}
