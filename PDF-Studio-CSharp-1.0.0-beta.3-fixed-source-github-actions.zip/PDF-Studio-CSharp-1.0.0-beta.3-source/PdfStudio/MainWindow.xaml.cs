using Microsoft.Win32;
using PdfSharp.Drawing;
using PdfSharp.Pdf.IO;
using Serilog;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PigDocument = UglyToad.PdfPig.PdfDocument;
using PigWord = UglyToad.PdfPig.Content.Word;

namespace PdfStudio;

public partial class MainWindow : Window
{
    private const string ApplicationTitle = "PDF Studio C# — 1.0.0-beta.3";
    private string? _sourcePath;
    private string? _path;
    private PigDocument? _pig;
    private int _pageIndex;
    private double _zoom = .70;
    private double _pdfWidth;
    private double _pdfHeight;
    private Point? _dragStart;
    private Rectangle? _selection;
    private ToolMode _mode = ToolMode.Edit;
    private EditOperation? _movingOperation;
    private EditOperation? _selectedOperation;
    private PlacedImageOperation? _movingImage;
    private PlacedImageOperation? _resizingImage;
    private PlacedImageOperation? _selectedImage;
    private Vector _moveOffset;
    private Point _resizeStartPoint;
    private Rect _resizeStartRect;
    private readonly List<EditOperation> _operations = [];
    private readonly List<PlacedImageOperation> _images = [];
    private string? _securityUserPassword;
    private string? _securityOwnerPassword;
    private bool _securityConfigured;
    private bool _securityAllowPrinting = true;
    private bool _securityAllowEditing;
    private bool _securityAllowCopy = true;
    private bool _securityAllowAnnotations;
    private bool _securityRemoveMetadata;
    private bool _secureRedaction = true;
    private readonly List<string> _batchInputFiles = [];
    private bool _hasUnsavedChanges;
    private string? _assetDirectory;
    private bool _updatingImageControls;
    private readonly Dictionary<int, string> _ocrResults = [];
    private CancellationTokenSource? _ocrCancellation;
    private bool _updatingOcrText;
    private CancellationTokenSource? _batchCancellation;
    private AppSettings _settings = SettingsStore.Load();

    public MainWindow()
    {
        InitializeComponent();
        ThemeBox.ItemsSource = ThemeManager.Names;
        ThemeBox.SelectedItem = SettingsStore.LoadTheme();
        RefreshSignatureTemplates();
        BatchActionBox.SelectedIndex = 0;
        OcrLanguageBox.SelectedIndex = 0;
        OcrPsmBox.SelectedIndex = 0;
        OcrDpiBox.SelectedIndex = 1;
        ApplySettingsToControls();
        Closing += MainWindow_Closing;
        Closed += (_, _) =>
        {
            _pig?.Dispose();
            _ocrCancellation?.Cancel();
            _batchCancellation?.Cancel();
            DeleteWorkingFile();
            DeleteAssetDirectory();
        };
        UpdateWindowTitle();
    }

    private async void Open_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "PDF (*.pdf)|*.pdf", Title = "Открыть PDF" };
        if (dialog.ShowDialog() != true) return;
        await OpenDocumentAsync(dialog.FileName);
    }

    public async Task OpenDocumentAsync(string fileName)
    {
        if (!File.Exists(fileName) ||
            !System.IO.Path.GetExtension(fileName).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("Выбранный файл не является доступным PDF.", "Открытие PDF");
            return;
        }
        if (!ConfirmDiscardChanges("Открыть другой PDF и потерять несохранённые изменения?")) return;
        var newPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(),
            $"pdf-studio-working-{Guid.NewGuid():N}.pdf");
        PigDocument? newPig = null;
        try
        {
            File.Copy(fileName, newPath);
            newPig = PigDocument.Open(newPath);
            _pig?.Dispose();
            DeleteWorkingFile();
            DeleteAssetDirectory();
            _sourcePath = System.IO.Path.GetFullPath(fileName);
            _path = newPath;
            _pig = newPig;
            newPig = null;
            _operations.Clear();
            _images.Clear();
            _ocrResults.Clear();
            ShowOcrResult(0);
            _selectedImage = null;
            SetDocumentChanged(false);
            BuildPagePlaceholders(_pig.NumberOfPages);
            PageList.SelectedIndex = 0;
            StatusText.Text = $"Открыт: {System.IO.Path.GetFileName(_sourcePath)}";
            Log.Information("Открыт PDF {Path}; страниц={Count}", LogPath(_sourcePath), _pig.NumberOfPages);
            await LoadThumbnailsAsync(_path, _pig.NumberOfPages);
        }
        catch (Exception ex)
        {
            newPig?.Dispose();
            if (File.Exists(newPath) && _path != newPath) File.Delete(newPath);
            Log.Error(ex, "Ошибка открытия PDF");
            MessageBox.Show(ex.Message, "Ошибка");
        }
    }

    private void Window_DragOver(object sender, DragEventArgs e)
    {
        e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) &&
                    e.Data.GetData(DataFormats.FileDrop) is string[] files &&
                    files.Length == 1 &&
                    System.IO.Path.GetExtension(files[0])
                        .Equals(".pdf", StringComparison.OrdinalIgnoreCase)
            ? DragDropEffects.Copy
            : DragDropEffects.None;
        e.Handled = true;
    }

    private async void Window_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(DataFormats.FileDrop) is string[] { Length: 1 } files)
            await OpenDocumentAsync(files[0]);
    }

    private void MainWindow_Closing(object? sender, CancelEventArgs e)
    {
        if (!ConfirmDiscardChanges("Закрыть программу и потерять несохранённые изменения?"))
            e.Cancel = true;
    }

    private bool ConfirmDiscardChanges(string message)
    {
        if (!_hasUnsavedChanges) return true;
        return MessageBox.Show(message, "Несохранённые изменения",
            MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    private void MarkDocumentChanged()
    {
        if (_path is not null) SetDocumentChanged(true);
    }

    private void SetDocumentChanged(bool value)
    {
        _hasUnsavedChanges = value;
        UpdateWindowTitle();
    }

    private void UpdateWindowTitle()
    {
        var fileName = _sourcePath is null ? null : System.IO.Path.GetFileName(_sourcePath);
        Title = $"{ApplicationTitle}{(fileName is null ? "" : $" — {fileName}")}{(_hasUnsavedChanges ? " *" : "")}";
    }

    private void BuildPagePlaceholders(int pageCount)
    {
        PageList.Items.Clear();
        for (var i = 0; i < pageCount; i++)
        {
            PageList.Items.Add(new Border
            {
                Width = 116, Height = 160, Margin = new Thickness(4, 5, 4, 5),
                Background = Brushes.White,
                BorderBrush = (Brush)FindResource("Border"), BorderThickness = new Thickness(1)
            });
        }
    }

    private void DeleteWorkingFile()
    {
        if (_path is null || _path == _sourcePath) return;
        try { if (File.Exists(_path)) File.Delete(_path); }
        catch (Exception ex) { Log.Warning(ex, "Не удалось удалить временный PDF {Path}", LogPath(_path)); }
        _path = null;
    }

    private string EnsureAssetDirectory()
    {
        if (_assetDirectory is null)
        {
            _assetDirectory = System.IO.Path.Combine(System.IO.Path.GetTempPath(),
                $"pdf-studio-assets-{Guid.NewGuid():N}");
            Directory.CreateDirectory(_assetDirectory);
        }
        return _assetDirectory;
    }

    private string ImportImageAsset(string sourcePath)
    {
        var directory = EnsureAssetDirectory();
        var fullSourcePath = System.IO.Path.GetFullPath(sourcePath);
        if (System.IO.Path.GetDirectoryName(fullSourcePath)?.Equals(
                directory, StringComparison.OrdinalIgnoreCase) == true)
            return fullSourcePath;
        var extension = System.IO.Path.GetExtension(sourcePath);
        var targetPath = System.IO.Path.Combine(directory, $"{Guid.NewGuid():N}{extension}");
        File.Copy(fullSourcePath, targetPath);
        return targetPath;
    }

    private void DeleteAssetDirectory()
    {
        if (_assetDirectory is null) return;
        try
        {
            if (Directory.Exists(_assetDirectory))
                Directory.Delete(_assetDirectory, recursive: true);
        }
        catch (Exception ex)
        {
            Log.Warning(ex, "Не удалось удалить временный каталог изображений {Path}", LogPath(_assetDirectory));
        }
        _assetDirectory = null;
    }

    private async Task LoadThumbnailsAsync(string path, int pageCount)
    {
        for (var i = 0; i < pageCount; i++)
        {
            var index = i;
            var thumbnail = await Task.Run(() =>
                PdfRenderService.Render(path, index, out _, out _, 120, 168));
            if (_path != path || index >= PageList.Items.Count) return;
            if (PageList.Items[index] is Border holder)
            {
                holder.Child = new Image
                {
                    Source = thumbnail,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(4)
                };
            }
        }
    }

    private void RenderPage()
    {
        if (_path is null || _pig is null) return;
        try
        {
            var bitmap = PdfRenderService.Render(_path, _pageIndex, out var pxWidth, out var pxHeight);
            var page = _pig.GetPage(_pageIndex + 1);
            _pdfWidth = page.Width;
            _pdfHeight = page.Height;
            PageImage.Source = bitmap;
            var width = pxWidth * _zoom;
            var height = pxHeight * _zoom;
            PageSurface.Width = width; PageSurface.Height = height;
            PageImage.Width = width; PageImage.Height = height;
            OverlayCanvas.Width = width; OverlayCanvas.Height = height;
            PageStatus.Text = $"Страница {_pageIndex + 1} / {_pig.NumberOfPages} · {_pdfWidth:0} × {_pdfHeight:0} pt";
            ZoomText.Text = $"{_zoom:P0}";
            DrawOperations();
        }
        catch (Exception ex) { Log.Error(ex, "Ошибка отображения страницы"); MessageBox.Show(ex.Message, "Ошибка отображения"); }
    }

    private void DrawOperations()
    {
        OverlayCanvas.Children.Clear();
        foreach (var op in _operations.Where(x => x.PageIndex == _pageIndex && !x.IsInvisible))
        {
            var r = PdfToDisplay(op.PdfRect);
            var border = new Border
            {
                Width = r.Width, Height = r.Height,
                Background = op.Kind == EditKind.Add ? Brushes.Transparent : Brushes.White,
                BorderBrush = op == _movingOperation || op == _selectedOperation
                    ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2783DE"))
                    : Brushes.Transparent,
                BorderThickness = op == _movingOperation || op == _selectedOperation
                    ? new Thickness(1) : new Thickness(0)
            };
            if (op.Kind != EditKind.Delete)
            {
                border.Child = new TextBlock
                {
                    Text = op.Text, TextWrapping = TextWrapping.Wrap,
                    FontFamily = new FontFamily(op.FontFamily), FontSize = op.FontSize * DisplayScaleX,
                    FontWeight = op.Bold ? FontWeights.Bold : FontWeights.Normal,
                    FontStyle = op.Italic ? FontStyles.Italic : FontStyles.Normal,
                    TextDecorations = op.Underline ? TextDecorations.Underline : null,
                    Foreground = new SolidColorBrush(op.Color), TextAlignment = op.Alignment,
                    LineHeight = op.FontSize * op.LineSpacing * DisplayScaleY
                };
            }
            Canvas.SetLeft(border, r.Left); Canvas.SetTop(border, r.Top); OverlayCanvas.Children.Add(border);
        }
        DrawImages();
    }

    private void DrawImages()
    {
        foreach (var imageOperation in _images.Where(x => x.PageIndex == _pageIndex))
        {
            try
            {
                var r = PdfToDisplay(imageOperation.PdfRect);
                var selected = imageOperation == _selectedImage ||
                               imageOperation == _movingImage ||
                               imageOperation == _resizingImage;
                var content = new Grid { Background = Brushes.Transparent };
                content.Children.Add(new Image
                {
                    Source = LoadImage(imageOperation.SourcePath),
                    Stretch = Stretch.Fill,
                    Opacity = imageOperation.Opacity
                });
                if (selected)
                {
                    content.Children.Add(new Rectangle
                    {
                        Width = 10,
                        Height = 10,
                        Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2783DE")),
                        Stroke = Brushes.White,
                        StrokeThickness = 1,
                        HorizontalAlignment = HorizontalAlignment.Right,
                        VerticalAlignment = VerticalAlignment.Bottom
                    });
                }
                var border = new Border
                {
                    Width = Math.Max(1, r.Width),
                    Height = Math.Max(1, r.Height),
                    BorderBrush = selected
                        ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2783DE"))
                        : Brushes.Transparent,
                    BorderThickness = selected ? new Thickness(1) : new Thickness(0),
                    Child = content,
                    RenderTransform = new RotateTransform(
                        imageOperation.RotationDegrees,
                        Math.Max(1, r.Width) / 2,
                        Math.Max(1, r.Height) / 2)
                };
                Canvas.SetLeft(border, r.Left);
                Canvas.SetTop(border, r.Top);
                OverlayCanvas.Children.Add(border);
            }
            catch (Exception ex)
            {
                Log.Warning(ex, "Не удалось отобразить изображение {Path}", LogPath(imageOperation.SourcePath));
            }
        }
    }

    private static BitmapImage LoadImage(string path)
    {
        var image = new BitmapImage();
        image.BeginInit();
        image.UriSource = new Uri(path, UriKind.Absolute);
        image.CacheOption = BitmapCacheOption.OnLoad;
        image.EndInit();
        image.Freeze();
        return image;
    }

    private static string CreateOpacityImage(string path, double opacity)
    {
        var source = LoadImage(path);
        var visual = new DrawingVisual();
        using (var context = visual.RenderOpen())
        {
            context.PushOpacity(Math.Clamp(opacity, 0, 1));
            context.DrawImage(source, new Rect(0, 0, source.PixelWidth, source.PixelHeight));
            context.Pop();
        }
        var bitmap = new RenderTargetBitmap(
            source.PixelWidth, source.PixelHeight, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(visual);
        var outputPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(),
            $"pdf-studio-opacity-{Guid.NewGuid():N}.png");
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var stream = File.Create(outputPath);
        encoder.Save(stream);
        return outputPath;
    }

    private double DisplayScaleX => _pdfWidth == 0 ? 1 : OverlayCanvas.Width / _pdfWidth;
    private double DisplayScaleY => _pdfHeight == 0 ? 1 : OverlayCanvas.Height / _pdfHeight;
    private Rect PdfToDisplay(Rect r) => new(r.X * DisplayScaleX, r.Y * DisplayScaleY, r.Width * DisplayScaleX, r.Height * DisplayScaleY);
    private Rect DisplayToPdf(Rect r) => new(r.X / DisplayScaleX, r.Y / DisplayScaleY, r.Width / DisplayScaleX, r.Height / DisplayScaleY);

    private void Canvas_Down(object sender, MouseButtonEventArgs e)
    {
        if (_pig is null) return;
        var point = e.GetPosition(OverlayCanvas);
        if (e.ClickCount >= 2)
        {
            _dragStart = null;
            _selection = null;
            _movingOperation = null;
            OverlayCanvas.ReleaseMouseCapture();
            ActivateDefaultEditMode();
            var existing = FindEditableOperationAt(point);
            if (existing is not null)
            {
                _selectedOperation = existing;
                EditExistingOperation(existing);
            }
            else
            {
                var hit = FindLineAt(point);
                if (hit is not null)
                    HandleSelection(hit.Value.Rect, hit.Value.Text);
                else
                    StatusText.Text = "Текст под курсором не найден";
            }
            e.Handled = true;
            return;
        }
        if (_mode == ToolMode.Move)
        {
            _resizingImage = null;
            _movingImage = FindImageAt(point);
            if (_movingImage is not null)
            {
                _selectedImage = _movingImage;
                SyncImageControls();
                var imageRect = PdfToDisplay(_movingImage.PdfRect);
                if (IsResizeHandle(imageRect, point))
                {
                    _resizingImage = _movingImage;
                    _movingImage = null;
                    _resizeStartPoint = point;
                    _resizeStartRect = _resizingImage.PdfRect;
                    StatusText.Text = "Изменяйте размер изображения за нижний правый угол";
                }
                else
                {
                    _moveOffset = point - imageRect.TopLeft;
                    StatusText.Text = "Перетаскивайте изображение, затем отпустите кнопку мыши";
                }
                OverlayCanvas.CaptureMouse();
                DrawOperations();
                return;
            }
            _movingOperation = _operations
                .Where(x => x.PageIndex == _pageIndex && x.Kind != EditKind.Delete)
                .Reverse()
                .FirstOrDefault(x => PdfToDisplay(x.PdfRect).Contains(point));
            if (_movingOperation is null)
            {
                _selectedOperation = null;
                _selectedImage = null;
                StatusText.Text = "Щёлкните по тексту или изображению";
                DrawOperations();
                return;
            }
            _selectedOperation = _movingOperation;
            var displayRect = PdfToDisplay(_movingOperation.PdfRect);
            _moveOffset = point - displayRect.TopLeft;
            OverlayCanvas.CaptureMouse();
            StatusText.Text = "Перетаскивайте текст, затем отпустите кнопку мыши";
            DrawOperations();
            return;
        }
        _dragStart = point;
        OverlayCanvas.CaptureMouse();
        _selection = new Rectangle { Stroke = Brushes.DodgerBlue, StrokeThickness = 2, StrokeDashArray = [4, 3], Fill = Brushes.Transparent };
        OverlayCanvas.Children.Add(_selection);
    }

    private void Canvas_Move(object sender, MouseEventArgs e)
    {
        if (_resizingImage is not null && e.LeftButton == MouseButtonState.Pressed)
        {
            var point = e.GetPosition(OverlayCanvas);
            var resizeDisplayRect = PdfToDisplay(_resizeStartRect);
            var width = Math.Max(20, Math.Min(OverlayCanvas.Width - resizeDisplayRect.Left, point.X - resizeDisplayRect.Left));
            var height = Math.Max(20, Math.Min(OverlayCanvas.Height - resizeDisplayRect.Top, point.Y - resizeDisplayRect.Top));
            if (_resizingImage.LockAspectRatio && _resizeStartRect.Height > 0)
            {
                var aspect = _resizeStartRect.Width / _resizeStartRect.Height;
                if (width / height > aspect)
                    width = Math.Max(20, height * aspect);
                else
                    height = Math.Max(20, width / aspect);
            }
            _resizingImage.PdfRect = DisplayToPdf(new Rect(
                resizeDisplayRect.Left, resizeDisplayRect.Top, width, height));
            DrawOperations();
            return;
        }
        if (_movingImage is not null && e.LeftButton == MouseButtonState.Pressed)
        {
            var point = e.GetPosition(OverlayCanvas);
            var old = PdfToDisplay(_movingImage.PdfRect);
            var x = Math.Clamp(point.X - _moveOffset.X, 0, Math.Max(0, OverlayCanvas.Width - old.Width));
            var y = Math.Clamp(point.Y - _moveOffset.Y, 0, Math.Max(0, OverlayCanvas.Height - old.Height));
            _movingImage.PdfRect = DisplayToPdf(new Rect(x, y, old.Width, old.Height));
            DrawOperations();
            return;
        }
        if (_movingOperation is not null && e.LeftButton == MouseButtonState.Pressed)
        {
            var point = e.GetPosition(OverlayCanvas);
            var old = PdfToDisplay(_movingOperation.PdfRect);
            var x = Math.Clamp(point.X - _moveOffset.X, 0, Math.Max(0, OverlayCanvas.Width - old.Width));
            var y = Math.Clamp(point.Y - _moveOffset.Y, 0, Math.Max(0, OverlayCanvas.Height - old.Height));
            _movingOperation.PdfRect = DisplayToPdf(new Rect(x, y, old.Width, old.Height));
            DrawOperations();
            return;
        }
        if (_dragStart is not Point start || _selection is null || e.LeftButton != MouseButtonState.Pressed) return;
        var now = e.GetPosition(OverlayCanvas); var rect = Normalize(start, now);
        Canvas.SetLeft(_selection, rect.Left); Canvas.SetTop(_selection, rect.Top); _selection.Width = rect.Width; _selection.Height = rect.Height;
    }

    private void Canvas_Up(object sender, MouseButtonEventArgs e)
    {
        if (_resizingImage is not null)
        {
            _resizingImage = null;
            OverlayCanvas.ReleaseMouseCapture();
            MarkDocumentChanged();
            StatusText.Text = "Размер изображения изменён — сохраните копию";
            DrawOperations();
            return;
        }
        if (_movingImage is not null)
        {
            _movingImage = null;
            OverlayCanvas.ReleaseMouseCapture();
            MarkDocumentChanged();
            StatusText.Text = "Положение изображения изменено — сохраните копию";
            DrawOperations();
            return;
        }
        if (_movingOperation is not null)
        {
            Log.Information("Перемещён текст page={Page} rect={Rect}", _pageIndex + 1, _movingOperation.PdfRect);
            _movingOperation = null;
            OverlayCanvas.ReleaseMouseCapture();
            MarkDocumentChanged();
            StatusText.Text = "Положение текста изменено — сохраните копию";
            DrawOperations();
            return;
        }
        if (_dragStart is not Point start || _pig is null) return;
        var end = e.GetPosition(OverlayCanvas); _dragStart = null; OverlayCanvas.ReleaseMouseCapture();
        var displayRect = Normalize(start, end);
        if (displayRect.Width < 7 || displayRect.Height < 7)
        {
            if (_mode == ToolMode.Edit)
            {
                var existing = FindEditableOperationAt(end);
                if (existing is not null)
                {
                    _selectedOperation = existing;
                    StatusText.Text = "Изменение выбрано: двойной щелчок — редактировать, Del — удалить";
                    DrawOperations();
                    return;
                }
                var existingImage = FindImageAt(end);
                if (existingImage is not null)
                {
                    _selectedImage = existingImage;
                    SyncImageControls();
                    StatusText.Text = "Изображение выбрано — выберите «✥ Рука» для перемещения или изменения размера";
                    DrawOperations();
                    return;
                }
                var sourceHit = FindLineAt(end);
                _selectedOperation = null;
                StatusText.Text = sourceHit is null
                    ? "Текст под курсором не найден"
                    : "Двойной щелчок откроет редактор исходного текста";
                DrawOperations();
                return;
            }
            var hit = FindLineAt(end);
            if (hit is null) { StatusText.Text = "Текст под курсором не найден"; DrawOperations(); return; }
            displayRect = PdfToDisplay(hit.Value.Rect);
            HandleSelection(hit.Value.Rect, hit.Value.Text);
        }
        else
        {
            var pdfRect = DisplayToPdf(displayRect);
            var text = ExtractText(pdfRect);
            HandleSelection(pdfRect, text);
        }
    }

    private EditOperation? FindEditableOperationAt(Point point) =>
        _operations
            .Where(x => x.PageIndex == _pageIndex && x.Kind != EditKind.Delete)
            .Reverse()
            .FirstOrDefault(x => PdfToDisplay(x.PdfRect).Contains(point));

    private PlacedImageOperation? FindImageAt(Point point) =>
        _images
            .Where(x => x.PageIndex == _pageIndex)
            .Reverse()
            .FirstOrDefault(x => PdfToDisplay(x.PdfRect).Contains(point));

    private static bool IsResizeHandle(Rect rect, Point point) =>
        point.X >= rect.Right - 18 && point.Y >= rect.Bottom - 18;

    private void EditExistingOperation(EditOperation operation)
    {
        _selectedOperation = operation;
        var editor = new TextEditorWindow(operation) { Owner = this };
        if (editor.ShowDialog() != true || editor.Result is null)
        {
            DrawOperations();
            return;
        }
        var value = editor.Result;
        operation.Text = value.Text;
        operation.FontFamily = value.FontFamily;
        operation.FontSize = value.FontSize;
        operation.Bold = value.Bold;
        operation.Italic = value.Italic;
        operation.Underline = value.Underline;
        operation.Color = value.Color;
        operation.Alignment = value.Alignment;
        operation.LineSpacing = value.LineSpacing;
        var minimumHeight = value.FontSize * value.LineSpacing * 1.25;
        if (operation.PdfRect.Height < minimumHeight)
            operation.PdfRect = new Rect(operation.PdfRect.X, operation.PdfRect.Y,
                operation.PdfRect.Width, Math.Min(minimumHeight, _pdfHeight - operation.PdfRect.Y));
        MarkDocumentChanged();
        StatusText.Text = "Добавленный текст изменён — сохраните копию";
        Log.Information("Отредактирован добавленный текст page={Page}", _pageIndex + 1);
        DrawOperations();
    }

    private void HandleSelection(Rect pdfRect, string text)
    {
        if (_mode == ToolMode.Delete)
        {
            _operations.Add(new EditOperation { PageIndex = _pageIndex, Kind = EditKind.Delete, PdfRect = pdfRect });
            MarkDocumentChanged();
            Log.Information("Удалена область page={Page} rect={Rect}", _pageIndex + 1, pdfRect); ActivateDefaultEditMode(); DrawOperations(); return;
        }
        var initialSize = _mode == ToolMode.Add ? 12 : Math.Clamp(pdfRect.Height * .35, 8, 18);
        var editor = new TextEditorWindow(_mode == ToolMode.Add ? "" : text, initialSize) { Owner = this };
        if (editor.ShowDialog() != true || editor.Result is null) { DrawOperations(); return; }
        var x = editor.Result;
        if (_mode == ToolMode.Add)
        {
            var minimumHeight = x.FontSize * x.LineSpacing * 1.25;
            if (pdfRect.Height < minimumHeight)
                pdfRect = new Rect(pdfRect.X, pdfRect.Y, pdfRect.Width, Math.Min(minimumHeight, _pdfHeight - pdfRect.Y));
        }
        var operation = new EditOperation
        {
            PageIndex = _pageIndex, Kind = _mode == ToolMode.Add ? EditKind.Add : EditKind.Edit,
            PdfRect = pdfRect, Text = x.Text, FontFamily = x.FontFamily,
            FontSize = x.FontSize, Bold = x.Bold, Italic = x.Italic, Underline = x.Underline,
            Color = x.Color, Alignment = x.Alignment, LineSpacing = x.LineSpacing
        };
        _operations.Add(operation);
        MarkDocumentChanged();
        _selectedOperation = operation;
        Log.Information("Добавлена операция {Kind} page={Page}", _mode, _pageIndex + 1);
        ActivateDefaultEditMode(); StatusText.Text = "Изменение добавлено — сохраните копию"; DrawOperations();
    }

    private void AddImage_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var dialog = new OpenFileDialog
        {
            Filter = "Изображения|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|Все файлы|*.*",
            Title = "Добавить изображение"
        };
        if (dialog.ShowDialog() != true) return;
        AddImageOperation(dialog.FileName, "Изображение");
    }

    private void DrawSignature_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var window = new SignatureWindow { Owner = this };
        if (window.ShowDialog() == true && window.SignaturePath is not null)
        {
            try
            {
                AddImageOperation(window.SignaturePath, "Подпись");
                if (!window.IsTemporary)
                    RefreshSignatureTemplates(window.SignaturePath);
            }
            finally
            {
                if (window.IsTemporary && File.Exists(window.SignaturePath))
                    File.Delete(window.SignaturePath);
            }
        }
    }

    private void UploadSignature_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var dialog = new OpenFileDialog
        {
            Filter = "Изображения подписи|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|Все файлы|*.*",
            Title = "Загрузить изображение подписи"
        };
        if (dialog.ShowDialog() != true) return;
        AddImageOperation(dialog.FileName, "Подпись");
    }

    private void UseSignatureTemplate_Click(object sender, RoutedEventArgs e)
    {
        if (SignatureTemplateBox.SelectedItem is not SignatureTemplate template)
        {
            StatusText.Text = "Выберите сохранённый шаблон подписи";
            return;
        }
        AddImageOperation(template.FilePath, "Подпись");
    }

    private void SignatureTemplateBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        SignatureTemplateNameBox.Text = SignatureTemplateBox.SelectedItem is SignatureTemplate template
            ? template.Name
            : "";
    }

    private void RenameSignatureTemplate_Click(object sender, RoutedEventArgs e)
    {
        if (SignatureTemplateBox.SelectedItem is not SignatureTemplate template)
        {
            StatusText.Text = "Выберите шаблон подписи";
            return;
        }
        var name = SanitizeTemplateName(SignatureTemplateNameBox.Text);
        if (string.IsNullOrWhiteSpace(name))
        {
            MessageBox.Show("Введите допустимое имя шаблона.", "Подпись");
            return;
        }
        var targetPath = System.IO.Path.Combine(SignatureTemplatesDirectory, name + ".png");
        if (File.Exists(targetPath) &&
            !targetPath.Equals(template.FilePath, StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("Шаблон с таким именем уже существует.", "Подпись");
            return;
        }
        if (!targetPath.Equals(template.FilePath, StringComparison.OrdinalIgnoreCase))
            File.Move(template.FilePath, targetPath);
        RefreshSignatureTemplates(targetPath);
        StatusText.Text = "Шаблон подписи переименован";
    }

    private void DeleteSignatureTemplate_Click(object sender, RoutedEventArgs e)
    {
        if (SignatureTemplateBox.SelectedItem is not SignatureTemplate template)
        {
            StatusText.Text = "Выберите шаблон подписи";
            return;
        }
        if (MessageBox.Show($"Удалить шаблон «{template.Name}»?", "Подпись",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        File.Delete(template.FilePath);
        RefreshSignatureTemplates();
        StatusText.Text = "Шаблон подписи удалён";
    }

    private void ClearSignatureTemplates_Click(object sender, RoutedEventArgs e)
    {
        var files = Directory.Exists(SignatureTemplatesDirectory)
            ? Directory.GetFiles(SignatureTemplatesDirectory, "*.png")
            : [];
        if (files.Length == 0)
        {
            StatusText.Text = "Сохранённых шаблонов нет";
            return;
        }
        if (MessageBox.Show($"Удалить все шаблоны подписей ({files.Length})?", "Подпись",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        foreach (var file in files) File.Delete(file);
        RefreshSignatureTemplates();
        StatusText.Text = "Все шаблоны подписей удалены";
    }

    private static string SanitizeTemplateName(string value)
    {
        var invalid = System.IO.Path.GetInvalidFileNameChars().ToHashSet();
        return new string(value.Trim()
            .Select(character => invalid.Contains(character) ? '_' : character).ToArray());
    }

    private void ApplySecurity_Click(object sender, RoutedEventArgs e)
    {
        _securityUserPassword = UserPasswordBox.Password;
        _securityOwnerPassword = OwnerPasswordBox.Password;
        _securityAllowPrinting = AllowPrintingBox.IsChecked == true;
        _securityAllowEditing = AllowEditingBox.IsChecked == true;
        _securityAllowCopy = AllowCopyBox.IsChecked == true;
        _securityAllowAnnotations = AllowAnnotationsBox.IsChecked == true;
        _securityRemoveMetadata = RemoveMetadataBox.IsChecked == true;
        _secureRedaction = SecureRedactionBox.IsChecked == true;
        _securityConfigured = !string.IsNullOrEmpty(_securityUserPassword) ||
                              !string.IsNullOrEmpty(_securityOwnerPassword) ||
                              !_securityAllowPrinting || !_securityAllowEditing ||
                              !_securityAllowCopy || !_securityAllowAnnotations ||
                              _securityRemoveMetadata;
        MarkDocumentChanged();
        StatusText.Text = _securityConfigured
            ? "Параметры защиты применятся при сохранении PDF"
            : "Защита отключена";
    }

    private void ClearSecurity_Click(object sender, RoutedEventArgs e)
    {
        UserPasswordBox.Clear();
        OwnerPasswordBox.Clear();
        AllowPrintingBox.IsChecked = true;
        AllowEditingBox.IsChecked = false;
        AllowCopyBox.IsChecked = true;
        AllowAnnotationsBox.IsChecked = false;
        RemoveMetadataBox.IsChecked = false;
        SecureRedactionBox.IsChecked = true;
        _securityUserPassword = null;
        _securityOwnerPassword = null;
        _securityConfigured = false;
        _securityAllowPrinting = true;
        _securityAllowEditing = false;
        _securityAllowCopy = true;
        _securityAllowAnnotations = false;
        _securityRemoveMetadata = false;
        _secureRedaction = true;
        MarkDocumentChanged();
        StatusText.Text = "Защита отключена";
    }

    private async void RunOcr_Click(object sender, RoutedEventArgs e) =>
        await RunOcrPagesAsync([_pageIndex]);

    private async void RunSelectedOcr_Click(object sender, RoutedEventArgs e) =>
        await RunOcrPagesAsync(GetSelectedPageIndices());

    private async void RunAllOcr_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        await RunOcrPagesAsync(Enumerable.Range(0, _pig.NumberOfPages).ToList());
    }

    private void CancelOcr_Click(object sender, RoutedEventArgs e) => _ocrCancellation?.Cancel();

    private async Task RunOcrPagesAsync(IReadOnlyList<int> pageIndices)
    {
        if (_path is null || _pig is null)
        {
            MessageBox.Show("Сначала откройте PDF.");
            return;
        }
        if (_ocrCancellation is not null)
        {
            StatusText.Text = "OCR уже выполняется";
            return;
        }
        var language = GetComboTag(OcrLanguageBox, "rus+eng");
        var psm = GetComboTag(OcrPsmBox, "3");
        var dpi = int.TryParse(GetComboTag(OcrDpiBox, "300"), out var parsedDpi)
            ? parsedDpi
            : 300;
        _ocrCancellation = new CancellationTokenSource();
        var token = _ocrCancellation.Token;
        OcrProgressBar.Maximum = pageIndices.Count;
        OcrProgressBar.Value = 0;
        try
        {
            for (var position = 0; position < pageIndices.Count; position++)
            {
                token.ThrowIfCancellationRequested();
                var pageIndex = pageIndices[position];
                StatusText.Text = $"OCR: страница {pageIndex + 1}, {position + 1} из {pageIndices.Count}";
                var bitmap = await Task.Run(() =>
                    PdfRenderService.Render(_path, pageIndex, out _, out _,
                        Math.Max(1200, (int)(dpi * 8.5)),
                        Math.Max(1600, (int)(dpi * 11.7))), token);
                token.ThrowIfCancellationRequested();
                var inputPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(),
                    $"pdf-studio-ocr-{Guid.NewGuid():N}.png");
                var outputBase = System.IO.Path.Combine(System.IO.Path.GetTempPath(),
                    $"pdf-studio-ocr-{Guid.NewGuid():N}");
                try
                {
                    var encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bitmap));
                    using (var stream = File.Create(inputPath)) encoder.Save(stream);
                    _ocrResults[pageIndex] = await RunTesseractAsync(
                        inputPath, outputBase, language, psm, token);
                }
                finally
                {
                    if (File.Exists(inputPath)) File.Delete(inputPath);
                    var outputPath = outputBase + ".txt";
                    if (File.Exists(outputPath)) File.Delete(outputPath);
                }
                OcrProgressBar.Value = position + 1;
            }
            ShowOcrResult(_pageIndex);
            var found = pageIndices.Count(index =>
                _ocrResults.TryGetValue(index, out var text) && !string.IsNullOrWhiteSpace(text));
            StatusText.Text = $"OCR завершён: страниц с текстом {found} из {pageIndices.Count}";
        }
        catch (OperationCanceledException)
        {
            StatusText.Text = "OCR отменён";
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Ошибка OCR");
            StatusText.Text = "Ошибка OCR";
            MessageBox.Show(ex.Message, "Ошибка OCR");
        }
        finally
        {
            _ocrCancellation.Dispose();
            _ocrCancellation = null;
        }
    }

    private static string GetComboTag(ComboBox comboBox, string fallback) =>
        (comboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? fallback;

    private static async Task<string> RunTesseractAsync(
        string inputPath,
        string outputBase,
        string language,
        string psm,
        CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = "tesseract",
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        startInfo.ArgumentList.Add(inputPath);
        startInfo.ArgumentList.Add(outputBase);
        startInfo.ArgumentList.Add("-l");
        startInfo.ArgumentList.Add(language);
        startInfo.ArgumentList.Add("--psm");
        startInfo.ArgumentList.Add(psm);
        using var process = Process.Start(startInfo)
            ?? throw new InvalidOperationException(
                "Tesseract OCR не найден. Установите Tesseract и добавьте tesseract.exe в PATH.");
        using var cancellation = cancellationToken.Register(() =>
        {
            try
            {
                if (!process.HasExited) process.Kill(entireProcessTree: true);
            }
            catch
            {
                // The process may exit between the checks.
            }
        });
        var errorTask = process.StandardError.ReadToEndAsync(cancellationToken);
        await process.WaitForExitAsync(cancellationToken);
        var error = await errorTask;
        if (process.ExitCode != 0)
            throw new InvalidOperationException(
                $"Tesseract не смог распознать страницу. Проверьте язык {language}.\n{error}");
        var outputPath = outputBase + ".txt";
        return File.Exists(outputPath) ? await File.ReadAllTextAsync(outputPath, cancellationToken) : "";
    }

    private void ShowOcrResult(int pageIndex)
    {
        _updatingOcrText = true;
        try
        {
            OcrTextBox.Text = _ocrResults.TryGetValue(pageIndex, out var text) ? text : "";
        }
        finally
        {
            _updatingOcrText = false;
        }
    }

    private void OcrTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_updatingOcrText || _pig is null) return;
        _ocrResults[_pageIndex] = OcrTextBox.Text;
    }

    private void EditOcrText_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(OcrTextBox.Text))
        {
            StatusText.Text = "Сначала выполните распознавание";
            return;
        }
        var editor = new TextEditorWindow(OcrTextBox.Text, 12) { Owner = this };
        if (editor.ShowDialog() == true && editor.Result is not null)
        {
            OcrTextBox.Text = editor.Result.Text;
            _ocrResults[_pageIndex] = editor.Result.Text;
            StatusText.Text = "Результат OCR отредактирован";
        }
    }

    private void InsertOcrText_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null)
        {
            MessageBox.Show("Сначала откройте PDF.");
            return;
        }
        if (string.IsNullOrWhiteSpace(OcrTextBox.Text))
        {
            StatusText.Text = "Сначала выполните распознавание";
            return;
        }
        var margin = Math.Min(36, Math.Min(_pdfWidth, _pdfHeight) / 10);
        var operation = new EditOperation
        {
            PageIndex = _pageIndex,
            Kind = EditKind.Add,
            PdfRect = new Rect(margin, margin, Math.Max(20, _pdfWidth - margin * 2),
                Math.Max(20, _pdfHeight - margin * 2)),
            Text = OcrTextBox.Text,
            FontFamily = "Arial",
            FontSize = 11,
            Color = Colors.Black,
            Alignment = TextAlignment.Left,
            LineSpacing = 1.15
        };
        _operations.Add(operation);
        MarkDocumentChanged();
        _selectedOperation = operation;
        DrawOperations();
        StatusText.Text = "OCR-текст добавлен как редактируемый слой";
    }

    private void InsertOcrSearchLayer_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null)
        {
            MessageBox.Show("Сначала откройте PDF.");
            return;
        }
        var selected = GetSelectedPageIndices();
        var inserted = 0;
        foreach (var pageIndex in selected)
        {
            if (!_ocrResults.TryGetValue(pageIndex, out var text) || string.IsNullOrWhiteSpace(text))
                continue;
            _operations.RemoveAll(operation =>
                operation.PageIndex == pageIndex && operation.IsOcrLayer);
            var page = _pig.GetPage(pageIndex + 1);
            const double margin = 18;
            _operations.Add(new EditOperation
            {
                PageIndex = pageIndex,
                Kind = EditKind.Add,
                PdfRect = new Rect(margin, margin,
                    Math.Max(20, page.Width - margin * 2),
                    Math.Max(20, page.Height - margin * 2)),
                Text = text,
                FontFamily = "Arial",
                FontSize = 8,
                Color = Colors.Transparent,
                Alignment = TextAlignment.Left,
                LineSpacing = 1.05,
                IsInvisible = true,
                IsOcrLayer = true
            });
            inserted++;
        }
        if (inserted == 0)
        {
            StatusText.Text = "Для выбранных страниц нет результатов OCR";
            return;
        }
        MarkDocumentChanged();
        DrawOperations();
        StatusText.Text = $"Поисковый OCR-слой добавлен: страниц {inserted}";
    }

    private void SelectBatchFiles_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "PDF (*.pdf)|*.pdf",
            Title = "Выбрать PDF для пакетной обработки",
            Multiselect = true
        };
        if (dialog.ShowDialog() != true) return;
        AddBatchFiles(dialog.FileNames);
    }

    private void SelectBatchFolder_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Выбрать папку с PDF" };
        if (dialog.ShowDialog() != true) return;
        var searchOption = BatchRecursiveBox.IsChecked == true
            ? SearchOption.AllDirectories
            : SearchOption.TopDirectoryOnly;
        AddBatchFiles(Directory.GetFiles(dialog.FolderName, "*.pdf", searchOption));
    }

    private void SelectBatchOutputDirectory_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Выбрать выходной каталог" };
        if (dialog.ShowDialog() == true)
            BatchOutputDirectoryBox.Text = dialog.FolderName;
    }

    private void ClearBatchFiles_Click(object sender, RoutedEventArgs e)
    {
        _batchInputFiles.Clear();
        RefreshBatchFileList();
        BatchReportList.ItemsSource = null;
        BatchStatusText.Text = "Очередь очищена";
    }

    private void AddBatchFiles(IEnumerable<string> paths)
    {
        foreach (var path in paths.Select(System.IO.Path.GetFullPath))
            if (!_batchInputFiles.Contains(path, StringComparer.OrdinalIgnoreCase))
                _batchInputFiles.Add(path);
        _batchInputFiles.Sort(StringComparer.OrdinalIgnoreCase);
        RefreshBatchFileList();
        BatchStatusText.Text = $"Выбрано файлов: {_batchInputFiles.Count}";
    }

    private void RefreshBatchFileList()
    {
        BatchFilesList.ItemsSource = _batchInputFiles
            .Select(path => $"{System.IO.Path.GetFileName(path)} — {System.IO.Path.GetDirectoryName(path)}")
            .ToList();
    }

    private async void RunBatch_Click(object sender, RoutedEventArgs e)
    {
        if (_batchInputFiles.Count == 0)
        {
            BatchStatusText.Text = "Сначала выберите PDF-файлы";
            return;
        }
        if (_batchCancellation is not null)
        {
            BatchStatusText.Text = "Пакетная обработка уже выполняется";
            return;
        }
        var action = BatchActionBox.SelectedIndex;
        if (action is 1 or 2 && !_securityConfigured)
        {
            BatchStatusText.Text = "Сначала настройте защиту в разделе «Защита»";
            return;
        }
        var configuredOutputDirectory = BatchOutputDirectoryBox.Text.Trim();
        if (configuredOutputDirectory.Length > 0)
            Directory.CreateDirectory(configuredOutputDirectory);
        _batchCancellation = new CancellationTokenSource();
        var token = _batchCancellation.Token;
        var succeeded = 0;
        var reports = new List<string>();
        BatchReportList.ItemsSource = reports.ToList();
        BatchProgressBar.Maximum = action == 3 ? 1 : _batchInputFiles.Count;
        BatchProgressBar.Value = 0;
        try
        {
            if (action == 3)
            {
                var directory = GetBatchBaseDirectory(_batchInputFiles[0], configuredOutputDirectory);
                var output = GetUniquePath(directory, "merged", ".pdf");
                await Task.Run(() => MergeBatchFiles(_batchInputFiles, output, token), token);
                reports.Add($"✓ Объединено файлов: {_batchInputFiles.Count} → {output}");
                succeeded = _batchInputFiles.Count;
                BatchProgressBar.Value = 1;
                BatchReportList.ItemsSource = reports.ToList();
            }
            else
            {
                for (var index = 0; index < _batchInputFiles.Count; index++)
                {
                    token.ThrowIfCancellationRequested();
                    var input = _batchInputFiles[index];
                    try
                    {
                        string report;
                        if (action <= 2)
                        {
                            var directory = GetBatchBaseDirectory(input, configuredOutputDirectory);
                            var output = GetUniquePath(directory,
                                System.IO.Path.GetFileNameWithoutExtension(input) + "_processed", ".pdf");
                            await Task.Run(() => ProcessBatchFile(input, output, action, token), token);
                            report = $"✓ {System.IO.Path.GetFileName(input)} → {output}";
                        }
                        else if (action == 4)
                        {
                            var directory = CreateBatchSubdirectory(
                                input, configuredOutputDirectory, "_pages");
                            var count = await Task.Run(() => SplitBatchPdf(input, directory, token), token);
                            report = $"✓ {System.IO.Path.GetFileName(input)}: страниц {count} → {directory}";
                        }
                        else
                        {
                            var directory = CreateBatchSubdirectory(
                                input, configuredOutputDirectory, "_images");
                            var count = await Task.Run(() => ExportBatchPages(input, directory, token), token);
                            report = $"✓ {System.IO.Path.GetFileName(input)}: PNG {count} → {directory}";
                        }
                        succeeded++;
                        reports.Add(report);
                    }
                    catch (Exception ex) when (ex is not OperationCanceledException)
                    {
                        reports.Add($"✗ {System.IO.Path.GetFileName(input)}: {ex.Message}");
                        Log.Error(ex, "Ошибка пакетной обработки {Path}", LogPath(input));
                    }
                    BatchProgressBar.Value = index + 1;
                    BatchReportList.ItemsSource = reports.ToList();
                    BatchStatusText.Text = $"Обработано: {index + 1} из {_batchInputFiles.Count}";
                }
            }
            var errors = reports.Count(report => report.StartsWith("✗", StringComparison.Ordinal));
            BatchStatusText.Text = $"Готово: {succeeded}, ошибок: {errors}";
            StatusText.Text = "Пакетная обработка завершена";
        }
        catch (OperationCanceledException)
        {
            reports.Add("— Обработка отменена пользователем");
            BatchReportList.ItemsSource = reports.ToList();
            BatchStatusText.Text = "Пакетная обработка отменена";
        }
        catch (Exception ex)
        {
            reports.Add($"✗ Пакетная операция: {ex.Message}");
            BatchReportList.ItemsSource = reports.ToList();
            BatchStatusText.Text = "Пакетная обработка завершилась с ошибкой";
            Log.Error(ex, "Ошибка пакетной операции");
        }
        finally
        {
            _batchCancellation.Dispose();
            _batchCancellation = null;
        }
    }

    private void CancelBatch_Click(object sender, RoutedEventArgs e) =>
        _batchCancellation?.Cancel();

    private static string GetBatchBaseDirectory(string input, string configuredDirectory)
    {
        var directory = configuredDirectory.Length > 0
            ? configuredDirectory
            : System.IO.Path.GetDirectoryName(input) ?? Environment.CurrentDirectory;
        Directory.CreateDirectory(directory);
        return directory;
    }

    private static string CreateBatchSubdirectory(
        string input, string configuredDirectory, string suffix)
    {
        var root = GetBatchBaseDirectory(input, configuredDirectory);
        var directory = System.IO.Path.Combine(root,
            System.IO.Path.GetFileNameWithoutExtension(input) + suffix);
        Directory.CreateDirectory(directory);
        return directory;
    }

    private static string GetUniquePath(string directory, string name, string extension)
    {
        var output = System.IO.Path.Combine(directory, name + extension);
        var index = 2;
        while (File.Exists(output))
        {
            output = System.IO.Path.Combine(directory, $"{name}_{index}{extension}");
            index++;
        }
        return output;
    }

    private void ProcessBatchFile(string input, string output, int action, CancellationToken token)
    {
        var temporary = output + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            token.ThrowIfCancellationRequested();
            File.Copy(input, temporary);
            using (var doc = PdfReader.Open(temporary, PdfDocumentOpenMode.Modify))
            {
                token.ThrowIfCancellationRequested();
                if (action is 0 or 2) RemoveMetadata(doc);
                if (action is 1 or 2) ApplySecurity(doc);
                doc.Save(output);
            }
        }
        finally
        {
            if (File.Exists(temporary)) File.Delete(temporary);
        }
    }

    private static void MergeBatchFiles(
        IReadOnlyList<string> inputs, string outputPath, CancellationToken token)
    {
        var temporary = outputPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var output = new PdfSharp.Pdf.PdfDocument())
            {
                foreach (var input in inputs)
                {
                    token.ThrowIfCancellationRequested();
                    using var source = PdfReader.Open(input, PdfDocumentOpenMode.Import);
                    for (var pageIndex = 0; pageIndex < source.PageCount; pageIndex++)
                    {
                        token.ThrowIfCancellationRequested();
                        output.AddPage(source.Pages[pageIndex]);
                    }
                }
                output.Save(temporary);
            }
            File.Move(temporary, outputPath);
        }
        finally
        {
            if (File.Exists(temporary)) File.Delete(temporary);
        }
    }

    private static int SplitBatchPdf(string input, string directory, CancellationToken token)
    {
        using var source = PdfReader.Open(input, PdfDocumentOpenMode.Import);
        var baseName = System.IO.Path.GetFileNameWithoutExtension(input);
        for (var pageIndex = 0; pageIndex < source.PageCount; pageIndex++)
        {
            token.ThrowIfCancellationRequested();
            using var output = new PdfSharp.Pdf.PdfDocument();
            output.AddPage(source.Pages[pageIndex]);
            var path = GetUniquePath(directory,
                $"{baseName}_page_{pageIndex + 1:0000}", ".pdf");
            output.Save(path);
        }
        return source.PageCount;
    }

    private static int ExportBatchPages(string input, string directory, CancellationToken token)
    {
        using var source = PigDocument.Open(input);
        var baseName = System.IO.Path.GetFileNameWithoutExtension(input);
        for (var pageIndex = 0; pageIndex < source.NumberOfPages; pageIndex++)
        {
            token.ThrowIfCancellationRequested();
            var bitmap = PdfRenderService.Render(input, pageIndex, out _, out _, 2400, 3400);
            var path = GetUniquePath(directory,
                $"{baseName}_page_{pageIndex + 1:0000}", ".png");
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var stream = File.Create(path);
            encoder.Save(stream);
        }
        return source.NumberOfPages;
    }

    private static string SignatureTemplatesDirectory =>
        System.IO.Path.Combine(App.DataDirectory, "signatures");

    private void RefreshSignatureTemplates(string? selectPath = null)
    {
        Directory.CreateDirectory(SignatureTemplatesDirectory);
        var templates = Directory.GetFiles(SignatureTemplatesDirectory, "*.png")
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .Select(path => new SignatureTemplate(System.IO.Path.GetFileNameWithoutExtension(path), path))
            .ToList();
        SignatureTemplateBox.ItemsSource = templates;
        if (selectPath is not null)
            SignatureTemplateBox.SelectedItem = templates.FirstOrDefault(template =>
                template.FilePath.Equals(selectPath, StringComparison.OrdinalIgnoreCase));
    }

    private void AddImageOperation(string path, string type)
    {
        try
        {
            var source = LoadImage(path);
            var assetPath = ImportImageAsset(path);
            var dpiX = source.DpiX > 0 ? source.DpiX : 96;
            var dpiY = source.DpiY > 0 ? source.DpiY : 96;
            var width = Math.Max(20, source.PixelWidth * 72.0 / dpiX);
            var height = Math.Max(20, source.PixelHeight * 72.0 / dpiY);
            var scale = Math.Min(250 / width, 180 / height);
            if (scale < 1) { width *= scale; height *= scale; }
            width = Math.Min(width, _pdfWidth * .7);
            height = Math.Min(height, _pdfHeight * .7);
            var operation = new PlacedImageOperation
            {
                PageIndex = _pageIndex,
                SourcePath = assetPath,
                PdfRect = new Rect(
                    Math.Max(0, (_pdfWidth - width) / 2),
                    Math.Max(0, (_pdfHeight - height) / 2),
                    width, height)
            };
            _images.Add(operation);
            MarkDocumentChanged();
            _selectedImage = operation;
            SyncImageControls();
            StatusText.Text = $"{type} добавлена — выберите «✥ Рука» для перемещения";
            Log.Information("Добавлен объект {Type} page={Page} path={Path}", type, _pageIndex + 1, LogPath(path));
            DrawOperations();
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Ошибка добавления изображения");
            MessageBox.Show(ex.Message, "Ошибка изображения");
        }
    }

    private void DeleteSelectedImage_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedImage is null)
        {
            StatusText.Text = "Сначала выберите изображение";
            return;
        }
        _images.Remove(_selectedImage);
        MarkDocumentChanged();
        _selectedImage = null;
        SyncImageControls();
        DrawOperations();
        StatusText.Text = "Изображение удалено";
    }

    private void DuplicateSelectedImage_Click(object sender, RoutedEventArgs e)
    {
        if (_selectedImage is null)
        {
            StatusText.Text = "Сначала выберите изображение";
            return;
        }
        var source = _selectedImage;
        var offset = 12.0;
        var rect = new Rect(
            Math.Min(Math.Max(0, _pdfWidth - source.PdfRect.Width), source.PdfRect.X + offset),
            Math.Min(Math.Max(0, _pdfHeight - source.PdfRect.Height), source.PdfRect.Y + offset),
            source.PdfRect.Width,
            source.PdfRect.Height);
        var duplicate = new PlacedImageOperation
        {
            PageIndex = source.PageIndex,
            SourcePath = source.SourcePath,
            PdfRect = rect,
            RotationDegrees = source.RotationDegrees,
            Opacity = source.Opacity,
            LockAspectRatio = source.LockAspectRatio
        };
        _images.Add(duplicate);
        _selectedImage = duplicate;
        MarkDocumentChanged();
        SyncImageControls();
        DrawOperations();
        StatusText.Text = "Изображение продублировано";
    }

    private void RotateImageLeft_Click(object sender, RoutedEventArgs e) => RotateSelectedImage(-90);

    private void RotateImageRight_Click(object sender, RoutedEventArgs e) => RotateSelectedImage(90);

    private void RotateSelectedImage(int degrees)
    {
        if (_selectedImage is null)
        {
            StatusText.Text = "Сначала выберите изображение";
            return;
        }
        _selectedImage.RotationDegrees =
            (_selectedImage.RotationDegrees + degrees % 360 + 360) % 360;
        MarkDocumentChanged();
        DrawOperations();
        StatusText.Text = $"Поворот изображения: {_selectedImage.RotationDegrees}°";
    }

    private void ImageOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_updatingImageControls || _selectedImage is null) return;
        _selectedImage.Opacity = Math.Clamp(ImageOpacitySlider.Value / 100, .1, 1);
        MarkDocumentChanged();
        DrawOperations();
        StatusText.Text = $"Прозрачность изображения: {ImageOpacitySlider.Value:0}%";
    }

    private void LockImageAspectBox_Changed(object sender, RoutedEventArgs e)
    {
        if (_updatingImageControls || _selectedImage is null) return;
        _selectedImage.LockAspectRatio = LockImageAspectBox.IsChecked == true;
        MarkDocumentChanged();
    }

    private void SyncImageControls()
    {
        _updatingImageControls = true;
        try
        {
            ImageOpacitySlider.Value = (_selectedImage?.Opacity ?? 1) * 100;
            LockImageAspectBox.IsChecked = _selectedImage?.LockAspectRatio ?? true;
        }
        finally
        {
            _updatingImageControls = false;
        }
    }

    private (Rect Rect, string Text)? FindLineAt(Point displayPoint)
    {
        if (_pig is null) return null;
        var p = new Point(displayPoint.X / DisplayScaleX, displayPoint.Y / DisplayScaleY);
        var words = _pig.GetPage(_pageIndex + 1).GetWords().ToList();
        var hit = words.FirstOrDefault(w => WordRect(w).Contains(p));
        if (hit is null) return null;
        var hitRect = WordRect(hit);
        var line = words.Where(w => Math.Abs(WordRect(w).Top + WordRect(w).Height / 2 - (hitRect.Top + hitRect.Height / 2)) < Math.Max(3, hitRect.Height * .6))
            .OrderBy(w => WordRect(w).Left).ToList();
        return (Union(line.Select(WordRect)), string.Join(" ", line.Select(w => w.Text)));
    }

    private string ExtractText(Rect rect)
    {
        if (_pig is null) return "";
        return string.Join(" ", _pig.GetPage(_pageIndex + 1).GetWords()
            .Where(w => WordRect(w).IntersectsWith(rect)).OrderBy(w => WordRect(w).Top).ThenBy(w => WordRect(w).Left).Select(w => w.Text));
    }

    private Rect WordRect(PigWord word)
    {
        var b = word.BoundingBox;
        return new Rect(b.Left, _pdfHeight - b.Top, b.Width, b.Height);
    }

    private static Rect Union(IEnumerable<Rect> rects)
    {
        var list = rects.ToList(); if (list.Count == 0) return Rect.Empty;
        var result = list[0]; foreach (var r in list.Skip(1)) result.Union(r); return result;
    }
    private static Rect Normalize(Point a, Point b) => new(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y), Math.Abs(a.X - b.X), Math.Abs(a.Y - b.Y));

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (_path is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var dialog = new SaveFileDialog
        {
            Filter = "PDF (*.pdf)|*.pdf|PNG (*.png)|*.png|JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|TIFF (*.tif;*.tiff)|*.tif;*.tiff|BMP (*.bmp)|*.bmp",
            DefaultExt = ".pdf",
            AddExtension = true,
            FileName = System.IO.Path.GetFileNameWithoutExtension(_sourcePath ?? _path) + "_edited.pdf",
            InitialDirectory = Directory.Exists(_settings.DefaultSaveDirectory)
                ? _settings.DefaultSaveDirectory
                : ""
        };
        if (dialog.ShowDialog() != true) return;
        try
        {
            var extension = System.IO.Path.GetExtension(dialog.FileName).ToLowerInvariant();
            if (extension == ".pdf")
            {
                if (_sourcePath is not null &&
                    System.IO.Path.GetFullPath(dialog.FileName).Equals(System.IO.Path.GetFullPath(_sourcePath), StringComparison.OrdinalIgnoreCase))
                    throw new IOException("Выберите другой файл, чтобы не перезаписать открытый оригинал.");
                SaveModifiedPdf(dialog.FileName);
                SetDocumentChanged(false);
                MessageBox.Show("Копия PDF сохранена.");
            }
            else
            {
                SaveCurrentPageImage(dialog.FileName, extension);
                MessageBox.Show($"Текущая страница сохранена как {extension.TrimStart('.').ToUpperInvariant()}.");
            }
            StatusText.Text = $"Сохранено: {System.IO.Path.GetFileName(dialog.FileName)}";
            Log.Information("Сохранён файл {Path}; операций={Count}", LogPath(dialog.FileName), _operations.Count);
        }
        catch (Exception ex) { Log.Error(ex, "Ошибка сохранения"); MessageBox.Show(ex.Message, "Ошибка сохранения"); }
    }

    private void SaveModifiedPdf(string outputPath, bool applySecurity = true)
    {
        if (_path is null) throw new InvalidOperationException("PDF не открыт.");
        var redactPages = _secureRedaction
            ? _operations.Where(operation => operation.Kind == EditKind.Delete)
                .Select(operation => operation.PageIndex).ToHashSet()
            : [];
        string? intermediatePath = redactPages.Count > 0
            ? System.IO.Path.Combine(System.IO.Path.GetTempPath(),
                $"pdf-studio-redaction-{Guid.NewGuid():N}.pdf")
            : null;
        try
        {
            using (var doc = PdfReader.Open(_path, PdfDocumentOpenMode.Modify))
            {
                for (var pageIndex = 0; pageIndex < doc.PageCount; pageIndex++)
                {
                    var operations = _operations.Where(o => o.PageIndex == pageIndex).ToList();
                    var images = _images.Where(i => i.PageIndex == pageIndex).ToList();
                    if (operations.Count == 0 && images.Count == 0) continue;
                    var page = doc.Pages[pageIndex];
                    using var gfx = XGraphics.FromPdfPage(page, XGraphicsPdfPageOptions.Append);
                    foreach (var op in operations)
                    {
                        var rect = new XRect(op.PdfRect.X, op.PdfRect.Y, op.PdfRect.Width, op.PdfRect.Height);
                        if (op.Kind != EditKind.Add) gfx.DrawRectangle(XBrushes.White, rect);
                        if (op.Kind != EditKind.Delete) DrawText(gfx, op, rect);
                    }
                    foreach (var image in images)
                    {
                        string? opacityPath = null;
                        try
                        {
                            var imagePath = image.SourcePath;
                            if (image.Opacity < .999)
                            {
                                opacityPath = CreateOpacityImage(image.SourcePath, image.Opacity);
                                imagePath = opacityPath;
                            }
                            using var xImage = XImage.FromFile(imagePath);
                            var rect = new XRect(image.PdfRect.X, image.PdfRect.Y,
                                image.PdfRect.Width, image.PdfRect.Height);
                            if (image.RotationDegrees == 0)
                            {
                                gfx.DrawImage(xImage, rect);
                            }
                            else
                            {
                                var state = gfx.Save();
                                try
                                {
                                    gfx.RotateAtTransform(image.RotationDegrees,
                                        new XPoint(rect.X + rect.Width / 2, rect.Y + rect.Height / 2));
                                    gfx.DrawImage(xImage, rect);
                                }
                                finally
                                {
                                    gfx.Restore(state);
                                }
                            }
                        }
                        finally
                        {
                            if (opacityPath is not null && File.Exists(opacityPath))
                                File.Delete(opacityPath);
                        }
                    }
                }
                if (intermediatePath is null)
                {
                    if (applySecurity && _securityConfigured)
                        ApplySecurity(doc);
                    doc.Save(outputPath);
                    return;
                }
                doc.Save(intermediatePath);
            }
            CreateSecureRedactionPdf(intermediatePath, outputPath, redactPages, applySecurity);
        }
        finally
        {
            if (intermediatePath is not null && File.Exists(intermediatePath))
                File.Delete(intermediatePath);
        }
    }

    private void CreateSecureRedactionPdf(
        string inputPath,
        string outputPath,
        IReadOnlySet<int> redactPages,
        bool applySecurity)
    {
        using var source = PdfReader.Open(inputPath, PdfDocumentOpenMode.Import);
        using var output = new PdfSharp.Pdf.PdfDocument();
        output.Info.Title = source.Info.Title;
        output.Info.Author = source.Info.Author;
        output.Info.Subject = source.Info.Subject;
        output.Info.Keywords = source.Info.Keywords;
        output.Info.Creator = source.Info.Creator;
        for (var pageIndex = 0; pageIndex < source.PageCount; pageIndex++)
        {
            if (!redactPages.Contains(pageIndex))
            {
                output.AddPage(source.Pages[pageIndex]);
                continue;
            }
            var bitmap = PdfRenderService.Render(inputPath, pageIndex, out _, out _, 2400, 3400);
            var imagePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(),
                $"pdf-studio-redacted-page-{Guid.NewGuid():N}.png");
            try
            {
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmap));
                using (var stream = File.Create(imagePath)) encoder.Save(stream);
                var sourcePage = source.Pages[pageIndex];
                var targetPage = output.AddPage();
                var rotated = Math.Abs(sourcePage.Rotate) % 180 != 0;
                targetPage.Width = rotated ? sourcePage.Height : sourcePage.Width;
                targetPage.Height = rotated ? sourcePage.Width : sourcePage.Height;
                using var gfx = XGraphics.FromPdfPage(targetPage);
                using var image = XImage.FromFile(imagePath);
                gfx.DrawImage(image, 0, 0, targetPage.Width.Point, targetPage.Height.Point);
            }
            finally
            {
                if (File.Exists(imagePath)) File.Delete(imagePath);
            }
        }
        if (applySecurity && _securityConfigured)
            ApplySecurity(output);
        output.Save(outputPath);
    }

    private void ApplySecurity(PdfSharp.Pdf.PdfDocument doc)
    {
        var ownerPassword = string.IsNullOrEmpty(_securityOwnerPassword)
            ? Convert.ToBase64String(Guid.NewGuid().ToByteArray())
            : _securityOwnerPassword;
        doc.SecuritySettings.UserPassword = _securityUserPassword ?? "";
        doc.SecuritySettings.OwnerPassword = ownerPassword;
        ConfigureAesEncryption(doc);
        doc.SecuritySettings.PermitPrint = _securityAllowPrinting;
        doc.SecuritySettings.PermitFullQualityPrint = _securityAllowPrinting;
        doc.SecuritySettings.PermitModifyDocument = _securityAllowEditing;
        doc.SecuritySettings.PermitAssembleDocument = _securityAllowEditing;
        doc.SecuritySettings.PermitFormsFill = _securityAllowAnnotations;
        doc.SecuritySettings.PermitAnnotations = _securityAllowAnnotations;
        doc.SecuritySettings.PermitExtractContent = _securityAllowCopy;
        if (_securityRemoveMetadata) RemoveMetadata(doc);
    }

    private void ConfigureAesEncryption(PdfSharp.Pdf.PdfDocument doc)
    {
        var handlerProperty = doc.SecuritySettings.GetType().GetProperty(
            "SecurityHandler", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        var handler = handlerProperty?.GetValue(doc.SecuritySettings);
        var method = handler?.GetType().GetMethod(
            "SetEncryptionToV4UsingAES",
            BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
            binder: null,
            types: [typeof(bool)],
            modifiers: null);
        method?.Invoke(handler, [!_securityRemoveMetadata]);
    }

    private static void RemoveMetadata(PdfSharp.Pdf.PdfDocument doc)
    {
        foreach (var key in new[]
                 {
                     "/Title", "/Author", "/Subject", "/Keywords", "/Creator", "/Producer",
                     "/CreationDate", "/ModDate", "/Trapped"
                 })
            doc.Info.Elements.Remove(key);
        doc.Internals.Catalog.Elements.Remove("/Metadata");
        doc.Internals.Catalog.Elements.Remove("/PieceInfo");
        foreach (var page in doc.Pages)
        {
            page.Elements.Remove("/Metadata");
            page.Elements.Remove("/PieceInfo");
        }
        PdfSharp.Pdf.PdfCustomValues.ClearAllCustomValues(doc);
    }

    private void SaveCurrentPageImage(string outputPath, string extension)
    {
        var tempPdf = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"pdf-studio-{Guid.NewGuid():N}.pdf");
        try
        {
            SaveModifiedPdf(tempPdf, applySecurity: false);
            var dpi = _settings.ExportDpi;
            var bitmap = PdfRenderService.Render(tempPdf, _pageIndex, out _, out _,
                Math.Max(1200, (int)(dpi * 8.5)),
                Math.Max(1600, (int)(dpi * 11.7)));
            BitmapEncoder encoder = extension switch
            {
                ".png" => new PngBitmapEncoder(),
                ".jpg" or ".jpeg" => new JpegBitmapEncoder { QualityLevel = _settings.JpegQuality },
                ".tif" or ".tiff" => new TiffBitmapEncoder { Compression = TiffCompressOption.Zip },
                ".bmp" => new BmpBitmapEncoder(),
                _ => throw new NotSupportedException($"Формат {extension} не поддерживается.")
            };
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var stream = File.Create(outputPath);
            encoder.Save(stream);
        }
        finally
        {
            if (File.Exists(tempPdf)) File.Delete(tempPdf);
        }
    }

    private static void DrawText(XGraphics gfx, EditOperation op, XRect rect)
    {
        var style = op.Bold && op.Italic ? XFontStyleEx.BoldItalic : op.Bold ? XFontStyleEx.Bold : op.Italic ? XFontStyleEx.Italic : XFontStyleEx.Regular;
        if (op.Underline) style |= XFontStyleEx.Underline;
        var font = new XFont(op.FontFamily, op.FontSize, style);
        var brush = new XSolidBrush(XColor.FromArgb(op.Color.A, op.Color.R, op.Color.G, op.Color.B));
        var y = rect.Y + op.FontSize * .88;
        foreach (var paragraph in op.Text.Replace("\r", "").Split('\n'))
        {
            var lines = new List<string>();
            var line = "";
            foreach (var word in paragraph.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            {
                var test = line.Length == 0 ? word : line + " " + word;
                if (gfx.MeasureString(test, font).Width <= rect.Width || line.Length == 0) line = test;
                else { lines.Add(line); line = word; }
            }
            if (line.Length > 0 || paragraph.Length == 0) lines.Add(line);
            for (var i = 0; i < lines.Count; i++)
            {
                DrawLine(gfx, lines[i], font, brush, rect, y, op.Alignment, i == lines.Count - 1);
                y += op.FontSize * op.LineSpacing;
                if (y > rect.Bottom) return;
            }
        }
    }

    private static void DrawLine(XGraphics gfx, string text, XFont font, XBrush brush, XRect rect, double baseline,
        TextAlignment alignment, bool isLastLine)
    {
        if (string.IsNullOrEmpty(text)) return;
        if (alignment == TextAlignment.Justify && !isLastLine)
        {
            var words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (words.Length > 1)
            {
                var wordsWidth = words.Sum(word => gfx.MeasureString(word, font).Width);
                var gap = Math.Max(0, (rect.Width - wordsWidth) / (words.Length - 1));
                var wordX = rect.X;
                foreach (var word in words)
                {
                    gfx.DrawString(word, font, brush, new XPoint(wordX, baseline));
                    wordX += gfx.MeasureString(word, font).Width + gap;
                }
                return;
            }
        }
        var width = gfx.MeasureString(text, font).Width;
        var x = alignment == TextAlignment.Center ? rect.X + (rect.Width - width) / 2 : alignment == TextAlignment.Right ? rect.Right - width : rect.X;
        gfx.DrawString(text, font, brush, new XPoint(x, baseline));
    }

    private EditState CaptureEditState() => new(
        _operations.Select(CloneOperation).ToList(),
        _images.Select(CloneImage).ToList(),
        new Dictionary<int, string>(_ocrResults));

    private void RestoreEditState(EditState state)
    {
        _operations.Clear();
        _operations.AddRange(state.Operations);
        _images.Clear();
        _images.AddRange(state.Images);
        _ocrResults.Clear();
        foreach (var item in state.OcrResults)
            _ocrResults[item.Key] = item.Value;
        _selectedOperation = null;
        _selectedImage = null;
        _movingOperation = null;
        _movingImage = null;
        _resizingImage = null;
        DrawOperations();
    }

    private static EditOperation CloneOperation(EditOperation source) => new()
    {
        PageIndex = source.PageIndex,
        Kind = source.Kind,
        PdfRect = source.PdfRect,
        Text = source.Text,
        FontFamily = source.FontFamily,
        FontSize = source.FontSize,
        Bold = source.Bold,
        Italic = source.Italic,
        Underline = source.Underline,
        Color = source.Color,
        Alignment = source.Alignment,
        LineSpacing = source.LineSpacing,
        IsInvisible = source.IsInvisible,
        IsOcrLayer = source.IsOcrLayer
    };

    private static PlacedImageOperation CloneImage(PlacedImageOperation source) => new()
    {
        PageIndex = source.PageIndex,
        SourcePath = source.SourcePath,
        PdfRect = source.PdfRect,
        RotationDegrees = source.RotationDegrees,
        Opacity = source.Opacity,
        LockAspectRatio = source.LockAspectRatio
    };

    private sealed record EditState(
        List<EditOperation> Operations,
        List<PlacedImageOperation> Images,
        Dictionary<int, string> OcrResults);

    private List<int> GetSelectedPageIndices()
    {
        var selected = PageList.SelectedItems.Cast<object>()
            .Select(item => PageList.Items.IndexOf(item))
            .Where(index => index >= 0)
            .Distinct()
            .OrderBy(index => index)
            .ToList();
        if (selected.Count == 0 && _pig is not null)
            selected.Add(Math.Clamp(_pageIndex, 0, _pig.NumberOfPages - 1));
        return selected;
    }

    private void SelectPageIndices(IEnumerable<int> indices)
    {
        PageList.SelectedItems.Clear();
        foreach (var index in indices.Distinct().OrderBy(value => value))
            if (index >= 0 && index < PageList.Items.Count)
                PageList.SelectedItems.Add(PageList.Items[index]);
    }

    private void ReindexObjects(IReadOnlyDictionary<int, int> oldToNew)
    {
        foreach (var op in _operations)
            if (oldToNew.TryGetValue(op.PageIndex, out var pageIndex))
                op.PageIndex = pageIndex;
        foreach (var image in _images)
            if (oldToNew.TryGetValue(image.PageIndex, out var pageIndex))
                image.PageIndex = pageIndex;
        var reindexedOcr = _ocrResults
            .Where(item => oldToNew.ContainsKey(item.Key))
            .ToDictionary(item => oldToNew[item.Key], item => item.Value);
        _ocrResults.Clear();
        foreach (var item in reindexedOcr)
            _ocrResults[item.Key] = item.Value;
    }

    private async void RotatePage_Click(object sender, RoutedEventArgs e) =>
        await RotateSelectedPagesAsync(90);

    private async void RotatePage180_Click(object sender, RoutedEventArgs e) =>
        await RotateSelectedPagesAsync(180);

    private async void RotatePage270_Click(object sender, RoutedEventArgs e) =>
        await RotateSelectedPagesAsync(270);

    private async Task RotateSelectedPagesAsync(int degrees)
    {
        if (_pig is null || _path is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var selected = GetSelectedPageIndices();
        var selectedSet = selected.ToHashSet();
        var editState = CaptureEditState();
        try
        {
            foreach (var pageIndex in selected)
            {
                var page = _pig.GetPage(pageIndex + 1);
                foreach (var op in _operations.Where(x => x.PageIndex == pageIndex))
                    op.PdfRect = RotateRect(op.PdfRect, page.Width, page.Height, degrees);
                foreach (var image in _images.Where(x => x.PageIndex == pageIndex))
                    image.PdfRect = RotateRect(image.PdfRect, page.Width, page.Height, degrees);
            }
            var rotations = selectedSet.ToDictionary(index => index, _ => degrees);
            await RewriteWorkingPdfAsync(
                Enumerable.Range(0, _pig.NumberOfPages).ToList(), selected[0], rotations);
            SelectPageIndices(selected);
            MarkDocumentChanged();
            StatusText.Text = $"Повернуто страниц: {selected.Count} на {degrees}°";
            Log.Information("Повернуты страницы {Pages} на {Degrees}°",
                string.Join(",", selected.Select(index => index + 1)), degrees);
        }
        catch (Exception ex)
        {
            RestoreEditState(editState);
            Log.Error(ex, "Ошибка поворота страниц");
            MessageBox.Show(ex.Message, "Ошибка");
        }
    }

    private static Rect RotateRect(Rect rect, double pageWidth, double pageHeight, int degrees) =>
        degrees switch
        {
            90 => new Rect(pageHeight - rect.Bottom, rect.X, rect.Height, rect.Width),
            180 => new Rect(pageWidth - rect.Right, pageHeight - rect.Bottom, rect.Width, rect.Height),
            270 => new Rect(rect.Y, pageWidth - rect.Right, rect.Height, rect.Width),
            _ => rect
        };

    private async void MovePageUp_Click(object sender, RoutedEventArgs e) =>
        await MoveSelectedPagesAsync(-1);

    private async void MovePageDown_Click(object sender, RoutedEventArgs e) =>
        await MoveSelectedPagesAsync(1);

    private async Task MoveSelectedPagesAsync(int direction)
    {
        if (_pig is null || _path is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var selected = GetSelectedPageIndices();
        if ((direction < 0 && selected[0] == 0) ||
            (direction > 0 && selected[^1] == _pig.NumberOfPages - 1)) return;
        var editState = CaptureEditState();
        try
        {
            var order = Enumerable.Range(0, _pig.NumberOfPages).ToList();
            var iteration = direction < 0 ? selected : selected.AsEnumerable().Reverse().ToList();
            foreach (var index in iteration)
                (order[index], order[index + direction]) = (order[index + direction], order[index]);

            var oldToNew = order.Select((oldIndex, newIndex) => (oldIndex, newIndex))
                .ToDictionary(pair => pair.oldIndex, pair => pair.newIndex);
            ReindexObjects(oldToNew);
            var newSelection = selected.Select(index => index + direction).ToList();
            await RewriteWorkingPdfAsync(order, newSelection[0]);
            SelectPageIndices(newSelection);
            MarkDocumentChanged();
            StatusText.Text = $"Перемещено страниц: {selected.Count}";
            Log.Information("Перемещены страницы {Pages}; направление={Direction}",
                string.Join(",", selected.Select(index => index + 1)), direction);
        }
        catch (Exception ex)
        {
            RestoreEditState(editState);
            Log.Error(ex, "Ошибка перемещения страниц");
            MessageBox.Show(ex.Message, "Ошибка");
        }
    }

    private async void DeletePage_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null || _path is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var selected = GetSelectedPageIndices();
        if (selected.Count >= _pig.NumberOfPages)
        {
            MessageBox.Show("Нельзя удалить все страницы документа.");
            return;
        }
        if (MessageBox.Show($"Удалить выбранные страницы ({selected.Count})?", "Удаление страниц",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        var selectedSet = selected.ToHashSet();
        var editState = CaptureEditState();
        try
        {
            var order = Enumerable.Range(0, _pig.NumberOfPages)
                .Where(index => !selectedSet.Contains(index)).ToList();
            _operations.RemoveAll(item => selectedSet.Contains(item.PageIndex));
            _images.RemoveAll(item => selectedSet.Contains(item.PageIndex));
            var oldToNew = order.Select((oldIndex, newIndex) => (oldIndex, newIndex))
                .ToDictionary(pair => pair.oldIndex, pair => pair.newIndex);
            ReindexObjects(oldToNew);
            var nextSelection = Math.Min(selected[0], order.Count - 1);
            await RewriteWorkingPdfAsync(order, nextSelection);
            MarkDocumentChanged();
            StatusText.Text = $"Удалено страниц: {selected.Count}";
            Log.Information("Удалены страницы {Pages}",
                string.Join(",", selected.Select(index => index + 1)));
        }
        catch (Exception ex)
        {
            RestoreEditState(editState);
            Log.Error(ex, "Ошибка удаления страниц");
            MessageBox.Show(ex.Message, "Ошибка");
        }
    }

    private void ExtractPage_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null || _path is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var selected = GetSelectedPageIndices();
        var suffix = selected.Count == 1
            ? $"page_{selected[0] + 1}"
            : $"pages_{selected[0] + 1}-{selected[^1] + 1}";
        var dialog = new SaveFileDialog
        {
            Filter = "PDF (*.pdf)|*.pdf",
            DefaultExt = ".pdf",
            AddExtension = true,
            FileName = $"{System.IO.Path.GetFileNameWithoutExtension(_sourcePath ?? _path)}_{suffix}.pdf",
            InitialDirectory = Directory.Exists(_settings.DefaultSaveDirectory)
                ? _settings.DefaultSaveDirectory
                : ""
        };
        if (dialog.ShowDialog() != true) return;
        var temp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"pdf-studio-extract-{Guid.NewGuid():N}.pdf");
        try
        {
            SaveModifiedPdf(temp, applySecurity: false);
            using var source = PdfReader.Open(temp, PdfDocumentOpenMode.Import);
            using var output = new PdfSharp.Pdf.PdfDocument();
            foreach (var pageIndex in selected)
                output.AddPage(source.Pages[pageIndex]);
            output.Save(dialog.FileName);
            StatusText.Text = $"Извлечено страниц: {selected.Count}";
            Log.Information("Извлечены страницы {Pages} в {Path}",
                string.Join(",", selected.Select(index => index + 1)), LogPath(dialog.FileName));
            MessageBox.Show($"Страницы сохранены в отдельный PDF: {selected.Count}.");
        }
        catch (Exception ex) { Log.Error(ex, "Ошибка извлечения страниц"); MessageBox.Show(ex.Message, "Ошибка"); }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }

    private async void MergePdf_Click(object sender, RoutedEventArgs e)
    {
        if (_pig is null || _path is null) { MessageBox.Show("Сначала откройте PDF."); return; }
        var dialog = new OpenFileDialog
        {
            Filter = "PDF (*.pdf)|*.pdf",
            Title = "Добавить PDF в текущий документ",
            Multiselect = true
        };
        if (dialog.ShowDialog() != true || dialog.FileNames.Length == 0) return;

        var oldPath = _path;
        var existingPageCount = _pig.NumberOfPages;
        var newPath = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(), $"pdf-studio-merge-{Guid.NewGuid():N}.pdf");
        try
        {
            using (var output = new PdfSharp.Pdf.PdfDocument())
            {
                AddPagesFromPdf(output, oldPath);
                foreach (var file in dialog.FileNames)
                {
                    if (System.IO.Path.GetFullPath(file).Equals(
                            System.IO.Path.GetFullPath(oldPath), StringComparison.OrdinalIgnoreCase))
                        continue;
                    AddPagesFromPdf(output, file);
                }
                output.Save(newPath);
            }

            await ReplaceWorkingPdfAsync(newPath, existingPageCount);
            MarkDocumentChanged();
            var totalPageCount = _pig.NumberOfPages;
            StatusText.Text = $"Добавлено PDF: страниц стало {totalPageCount}";
            Log.Information("Объединены PDF; файлов={Files}; добавлено страниц={AddedPages}; всего страниц={Pages}",
                dialog.FileNames.Length, totalPageCount - existingPageCount, totalPageCount);
            MessageBox.Show($"Документы объединены. Всего страниц: {totalPageCount}.",
                "Объединение PDF");
        }
        catch (Exception ex)
        {
            if (File.Exists(newPath)) File.Delete(newPath);
            Log.Error(ex, "Ошибка объединения PDF");
            MessageBox.Show(ex.Message, "Ошибка объединения");
        }
    }

    private static void AddPagesFromPdf(PdfSharp.Pdf.PdfDocument output, string path)
    {
        using var source = PdfReader.Open(path, PdfDocumentOpenMode.Import);
        for (var i = 0; i < source.PageCount; i++)
            output.AddPage(source.Pages[i]);
    }

    private async Task ReplaceWorkingPdfAsync(string replacementPath, int selectedIndex)
    {
        if (_path is null) throw new InvalidOperationException("PDF не открыт.");
        var oldPath = _path;
        PigDocument? replacementPig = PigDocument.Open(replacementPath);
        try
        {
            if (replacementPig.NumberOfPages < 1)
                throw new InvalidDataException("Объединённый PDF не содержит страниц.");

            _pig?.Dispose();
            _pig = replacementPig;
            replacementPig = null;
            _path = replacementPath;
            BuildPagePlaceholders(_pig.NumberOfPages);
            PageList.SelectedIndex = Math.Clamp(selectedIndex, 0, _pig.NumberOfPages - 1);
            await LoadThumbnailsAsync(_path, _pig.NumberOfPages);
            if (File.Exists(oldPath)) File.Delete(oldPath);
        }
        catch
        {
            _pig?.Dispose();
            _pig = null;
            if (File.Exists(replacementPath)) File.Delete(replacementPath);
            _path = oldPath;
            _pig = PigDocument.Open(oldPath);
            BuildPagePlaceholders(_pig.NumberOfPages);
            PageList.SelectedIndex = Math.Clamp(selectedIndex, 0, _pig.NumberOfPages - 1);
            throw;
        }
        finally
        {
            replacementPig?.Dispose();
        }
    }

    private async Task RewriteWorkingPdfAsync(
        IReadOnlyList<int> order,
        int selectedIndex,
        IReadOnlyDictionary<int, int>? rotations = null)
    {
        if (_path is null) throw new InvalidOperationException("PDF не открыт.");
        var oldPath = _path;
        var newPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"pdf-studio-working-{Guid.NewGuid():N}.pdf");
        try
        {
            using (var source = PdfReader.Open(oldPath, PdfDocumentOpenMode.Import))
            using (var output = new PdfSharp.Pdf.PdfDocument())
            {
                for (var i = 0; i < order.Count; i++)
                {
                    var page = output.AddPage(source.Pages[order[i]]);
                    if (rotations?.TryGetValue(i, out var degrees) == true)
                        page.Rotate = (page.Rotate + degrees) % 360;
                }
                output.Save(newPath);
            }

            await ReplaceWorkingPdfAsync(newPath, selectedIndex);
        }
        catch
        {
            if (File.Exists(newPath)) File.Delete(newPath);
            throw;
        }
    }

    private void Undo_Click(object sender, RoutedEventArgs e)
    {
        if (_operations.Count > 0)
        {
            var removed = _operations[^1];
            _operations.RemoveAt(_operations.Count - 1);
            if (_selectedOperation == removed) _selectedOperation = null;
            MarkDocumentChanged();
            DrawOperations();
            StatusText.Text = "Последнее изменение отменено";
        }
    }
    private void ZoomIn_Click(object sender, RoutedEventArgs e) { _zoom = Math.Min(1.8, _zoom + .1); RenderPage(); }
    private void ZoomOut_Click(object sender, RoutedEventArgs e) { _zoom = Math.Max(.3, _zoom - .1); RenderPage(); }
    private void PageList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var selectedIndex = e.AddedItems.Count > 0
            ? PageList.Items.IndexOf(e.AddedItems[^1])
            : PageList.SelectedIndex;
        if (selectedIndex >= 0)
        {
            _pageIndex = selectedIndex;
            _selectedOperation = null;
            _selectedImage = null;
            RenderPage();
            ShowOcrResult(_pageIndex);
            if (PageList.SelectedItems.Count > 1)
                StatusText.Text = $"Выбрано страниц: {PageList.SelectedItems.Count}";
        }
    }
    private void Mode_Click(object sender, RoutedEventArgs e)
    {
        _mode = sender == AddMode ? ToolMode.Add :
                sender == DeleteMode ? ToolMode.Delete :
                sender == MoveMode ? ToolMode.Move : ToolMode.Edit;
        AddMode.IsChecked = _mode == ToolMode.Add;
        DeleteMode.IsChecked = _mode == ToolMode.Delete;
        MoveMode.IsChecked = _mode == ToolMode.Move;
        OverlayCanvas.Cursor = _mode == ToolMode.Move ? Cursors.Hand : Cursors.Cross;
        StatusText.Text = _mode == ToolMode.Edit ? "Щёлкните по тексту или выделите абзац" :
                          _mode == ToolMode.Add ? "Выделите область для нового текста" :
                          _mode == ToolMode.Delete ? "Выделите удаляемую область" :
                          "Перетащите текст или изображение; размер изображения меняется за угол";
    }

    private void ActivateDefaultEditMode()
    {
        _mode = ToolMode.Edit;
        AddMode.IsChecked = false;
        DeleteMode.IsChecked = false;
        MoveMode.IsChecked = false;
        OverlayCanvas.Cursor = Cursors.Cross;
        StatusText.Text = "Щёлкните по тексту или выделите область";
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && e.Key == Key.O)
        {
            Open_Click(this, new RoutedEventArgs());
            e.Handled = true;
        }
        else if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && e.Key == Key.S)
        {
            Save_Click(this, new RoutedEventArgs());
            e.Handled = true;
        }
        else if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && e.Key == Key.Z)
        {
            Undo_Click(this, new RoutedEventArgs());
            e.Handled = true;
        }
        else if (e.Key == Key.Delete && _selectedOperation is not null)
        {
            var removed = _selectedOperation;
            _operations.Remove(removed);
            _selectedOperation = null;
            _movingOperation = null;
            MarkDocumentChanged();
            DrawOperations();
            StatusText.Text = "Выбранное изменение удалено";
            Log.Information("Удалено выбранное изменение page={Page}", removed.PageIndex + 1);
            e.Handled = true;
        }
        else if (e.Key == Key.Delete && _selectedImage is not null)
        {
            var removed = _selectedImage;
            _images.Remove(removed);
            _selectedImage = null;
            MarkDocumentChanged();
            DrawOperations();
            StatusText.Text = "Выбранное изображение удалено";
            Log.Information("Удалено изображение page={Page}", removed.PageIndex + 1);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            _selectedOperation = null;
            _selectedImage = null;
            _movingOperation = null;
            _movingImage = null;
            _resizingImage = null;
            ActivateDefaultEditMode();
            DrawOperations();
            e.Handled = true;
        }
    }

    private void ApplySettingsToControls()
    {
        DefaultSaveDirectoryBox.Text = _settings.DefaultSaveDirectory;
        JpegQualitySlider.Value = _settings.JpegQuality;
        SelectComboByTag(ExportDpiBox, _settings.ExportDpi.ToString());
        SelectComboByTag(OcrLanguageBox, _settings.OcrLanguage);
        SelectComboByTag(OcrPsmBox, _settings.OcrPsm);
        SelectComboByTag(OcrDpiBox, _settings.OcrDpi.ToString());
        SelectComboByTag(LogRetentionBox, _settings.LogRetentionDays.ToString());
        LogFullPathsBox.IsChecked = _settings.LogFullPaths;
    }

    private static void SelectComboByTag(ComboBox comboBox, string tag)
    {
        comboBox.SelectedItem = comboBox.Items.Cast<ComboBoxItem>()
            .FirstOrDefault(item => item.Tag?.ToString() == tag);
        if (comboBox.SelectedIndex < 0 && comboBox.Items.Count > 0)
            comboBox.SelectedIndex = 0;
    }

    private void SelectDefaultSaveDirectory_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Каталог сохранения по умолчанию" };
        if (dialog.ShowDialog() == true)
            DefaultSaveDirectoryBox.Text = dialog.FolderName;
    }

    private void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        var directory = DefaultSaveDirectoryBox.Text.Trim();
        if (directory.Length > 0)
            Directory.CreateDirectory(directory);
        _settings = new AppSettings
        {
            Theme = ThemeBox.SelectedItem as string ?? "Серая",
            DefaultSaveDirectory = directory,
            JpegQuality = (int)Math.Round(JpegQualitySlider.Value),
            ExportDpi = int.Parse(GetComboTag(ExportDpiBox, "300"), CultureInfo.InvariantCulture),
            OcrLanguage = GetComboTag(OcrLanguageBox, "rus+eng"),
            OcrPsm = GetComboTag(OcrPsmBox, "3"),
            OcrDpi = int.Parse(GetComboTag(OcrDpiBox, "300"), CultureInfo.InvariantCulture),
            LogRetentionDays = int.Parse(GetComboTag(LogRetentionBox, "7"), CultureInfo.InvariantCulture),
            LogFullPaths = LogFullPathsBox.IsChecked == true
        };
        SettingsStore.Save(_settings);
        StatusText.Text = "Настройки сохранены";
    }

    private void ResetSettings_Click(object sender, RoutedEventArgs e)
    {
        if (MessageBox.Show("Сбросить настройки к значениям по умолчанию?", "Настройки",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        _settings = new AppSettings();
        SettingsStore.Save(_settings);
        ThemeManager.Apply(_settings.Theme);
        ThemeBox.SelectedItem = _settings.Theme;
        ApplySettingsToControls();
        StatusText.Text = "Настройки сброшены";
    }

    private void ClearLogs_Click(object sender, RoutedEventArgs e)
    {
        Directory.CreateDirectory(App.LogDirectory);
        var deleted = 0;
        foreach (var file in Directory.GetFiles(App.LogDirectory, "*.log"))
        {
            if (File.GetLastWriteTime(file).Date >= DateTime.Today) continue;
            try
            {
                File.Delete(file);
                deleted++;
            }
            catch (IOException)
            {
                // An active or externally opened log can be skipped safely.
            }
        }
        StatusText.Text = $"Удалено старых журналов: {deleted}";
    }

    private async void RunDiagnostics_Click(object sender, RoutedEventArgs e)
    {
        DiagnosticsTextBox.Text = "Диагностика выполняется…";
        var report = new StringBuilder();
        report.AppendLine($"Версия: {ApplicationTitle}");
        report.AppendLine($"ОС: {RuntimeInformation.OSDescription}");
        report.AppendLine($"Архитектура: {RuntimeInformation.OSArchitecture}");
        report.AppendLine($".NET: {Environment.Version}");
        report.AppendLine($"64-битный процесс: {Environment.Is64BitProcess}");
        report.AppendLine($"Каталог данных: {CheckWritableDirectory(App.DataDirectory)}");
        report.AppendLine($"Временный каталог: {CheckWritableDirectory(System.IO.Path.GetTempPath())}");
        try
        {
            var result = await Task.Run(SelfTest.RunAuto);
            report.AppendLine(
                $"PDF self-test: OK, страниц {result.Pages}, {result.Width}×{result.Height}px");
        }
        catch (Exception ex)
        {
            report.AppendLine($"PDF self-test: ОШИБКА — {ex.Message}");
        }
        try
        {
            var version = await RunDiagnosticProcessAsync("tesseract", "--version");
            var languages = await RunDiagnosticProcessAsync("tesseract", "--list-langs");
            report.AppendLine($"Tesseract: {version.Split('\n', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault()}");
            report.AppendLine("Языки OCR: " + string.Join(", ",
                languages.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Where(line => !line.StartsWith("List of available", StringComparison.OrdinalIgnoreCase))));
        }
        catch (Exception ex)
        {
            report.AppendLine($"Tesseract: недоступен — {ex.Message}");
        }
        DiagnosticsTextBox.Text = report.ToString();
        StatusText.Text = "Диагностика завершена";
    }

    private static string CheckWritableDirectory(string directory)
    {
        try
        {
            Directory.CreateDirectory(directory);
            var path = System.IO.Path.Combine(directory, $".write-test-{Guid.NewGuid():N}");
            File.WriteAllText(path, "ok");
            File.Delete(path);
            return "доступен для записи";
        }
        catch (Exception ex)
        {
            return $"ошибка записи — {ex.Message}";
        }
    }

    private static async Task<string> RunDiagnosticProcessAsync(string fileName, string argument)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = fileName,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        startInfo.ArgumentList.Add(argument);
        using var process = Process.Start(startInfo)
            ?? throw new InvalidOperationException($"Не удалось запустить {fileName}.");
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(10));
        var outputTask = process.StandardOutput.ReadToEndAsync(timeout.Token);
        var errorTask = process.StandardError.ReadToEndAsync(timeout.Token);
        await process.WaitForExitAsync(timeout.Token);
        var output = await outputTask;
        var error = await errorTask;
        if (process.ExitCode != 0)
            throw new InvalidOperationException(string.IsNullOrWhiteSpace(error)
                ? $"Код завершения {process.ExitCode}"
                : error.Trim());
        return string.IsNullOrWhiteSpace(output) ? error.Trim() : output.Trim();
    }

    private string LogPath(string path) => _settings.LogFullPaths
        ? path
        : System.IO.Path.GetFileName(path);


    private void Workflow_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: string tag } && int.TryParse(tag, out var index) &&
            index >= 0 && index < ToolTabs.Items.Count)
            ToolTabs.SelectedIndex = index;
    }

    private void SettingsPanel_Click(object sender, RoutedEventArgs e) => ToolTabs.SelectedIndex = 7;

    private void ThemeBox_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (ThemeBox.SelectedItem is string theme) { ThemeManager.Apply(theme); Log.Information("Выбрана тема {Theme}", theme); } }
    private void Logs_Click(object sender, RoutedEventArgs e) { Directory.CreateDirectory(App.LogDirectory); Process.Start(new ProcessStartInfo(App.LogDirectory) { UseShellExecute = true }); }
}
