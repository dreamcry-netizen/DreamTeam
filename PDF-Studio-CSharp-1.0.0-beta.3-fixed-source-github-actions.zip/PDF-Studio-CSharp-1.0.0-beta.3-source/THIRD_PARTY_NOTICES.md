# Сторонние компоненты

- Docnet.Core 2.6.0 — MIT; обёртка PDFium.
- PDFium — BSD-style license и лицензии сторонних компонентов.
- PdfPig 0.1.16 — Apache License 2.0.
- PDFsharp-WPF 6.2.4 — MIT.
- Serilog 4.4.0 — Apache License 2.0.
- Serilog.Sinks.File 7.0.0 — Apache License 2.0.

Точные тексты лицензий доступны в пакетах NuGet и исходных репозиториях соответствующих проектов.
