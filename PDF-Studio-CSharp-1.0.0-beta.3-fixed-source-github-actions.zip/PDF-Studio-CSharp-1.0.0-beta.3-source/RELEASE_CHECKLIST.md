# Release checklist

1. Build on `windows-2022` with .NET 8 SDK.
2. Run `PDF-Studio-CSharp.exe --self-test-auto` and require exit code 0.
3. Open representative text, scanned, rotated, encrypted, and damaged PDFs.
4. Verify page operations, secure redaction, OCR, images, signatures, and batch jobs.
5. Verify saved PDFs in at least two independent viewers.
6. Scan the EXE and installer, then sign both when a code-signing certificate is available.
7. Compare the published SHA-256 checksum and archive release artifacts.
